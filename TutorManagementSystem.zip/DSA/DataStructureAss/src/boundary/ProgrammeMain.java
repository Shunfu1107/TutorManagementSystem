/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;


import adt.ArraySortedSetList;
import control.ProgramManagement;
import control.TutorialManagement;
import entity.Programme;
import entity.Tutorial;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Shufu
 */
public class ProgrammeMain {
    private ArraySortedSetList<Tutorial> tutorialList = new ArraySortedSetList<>();
    private ArraySortedSetList<Programme> programmeList = new ArraySortedSetList<>();
    
    
    private static Scanner scan = new Scanner(System.in);
     public static void clearConsole() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception E) {
            System.out.println(E);
        }
    }

    public static void generateDefaultData(){
        TutorialManagement.TutorialTable.put("G1",new Tutorial("G1", 18, "RIS"));
        TutorialManagement.TutorialTable.put("G2",new Tutorial("G2", 30, "RIS"));
        TutorialManagement.TutorialTable.put("G3",new Tutorial("G3", 21, "RIS"));
        TutorialManagement.TutorialTable.put("G4",new Tutorial("G4", 25, "RIS"));
        
        TutorialManagement.TutorialTable.put("G5",new Tutorial("G5", 18, "RDS"));
        TutorialManagement.TutorialTable.put("G6",new Tutorial("G6", 30, "RDS"));
        TutorialManagement.TutorialTable.put("G7",new Tutorial("G7", 21, "RDS"));
        TutorialManagement.TutorialTable.put("G8",new Tutorial("G8", 25, "RDS"));
        
        TutorialManagement.TutorialTable.put("G9",new Tutorial("G9", 18, "RSS"));
        TutorialManagement.TutorialTable.put("G10",new Tutorial("G10", 30, "RSS"));
        TutorialManagement.TutorialTable.put("G11",new Tutorial("G11", 21, "RSS"));
        TutorialManagement.TutorialTable.put("G12",new Tutorial("G12", 25, "RSS"));
            
        ProgramManagement.programLinkedList.add(new Programme(1,"RIS", "Data Structure", "ALI"));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(1));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(2));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(3));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(4));

        ProgramManagement.programLinkedList.add(new Programme(2, "RDS","HCI", "ABU"));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(5));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(6));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(7));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(8));

        ProgramManagement.programLinkedList.add(new Programme( 3,"RSS", "OOAD", "John"));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(9));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(10));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(11));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(12));
        
//        ProgramManagement.programLinkedList.add(new Programme( 4,"RIS", "CN", "Tee"));
//        ProgramManagement.programLinkedList.getEntry(3).addTutorial(TutorialManagement.getTutorial(1));
//        ProgramManagement.programLinkedList.getEntry(3).addTutorial(TutorialManagement.getTutorial(2));
//        ProgramManagement.programLinkedList.getEntry(3).addTutorial(TutorialManagement.getTutorial(3));
//        ProgramManagement.programLinkedList.getEntry(3).addTutorial(TutorialManagement.getTutorial(4));
//        
//        ProgramManagement.programLinkedList.add(new Programme(5,"RDS", "FCN", "Ong"));
//        ProgramManagement.programLinkedList.getEntry(4).addTutorial(TutorialManagement.getTutorial(5));
//        ProgramManagement.programLinkedList.getEntry(4).addTutorial(TutorialManagement.getTutorial(6));
//        ProgramManagement.programLinkedList.getEntry(4).addTutorial(TutorialManagement.getTutorial(7));
//        ProgramManagement.programLinkedList.getEntry(4).addTutorial(TutorialManagement.getTutorial(8));
    }
    
    public static void main(String[] args) {
            ProgrammeMain shuMain = new ProgrammeMain();
            shuMain.startUI();
    }
    
    public void startUI(){
           generateDefaultData();
        int choice = 0;
        do {
            //clearConsole();
            System.out.println("Welcome to the Programme and Tutorial Management Subsystem");
            System.out.println("1. Programme");
            System.out.println("2. Tutorial");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            try {
                choice = scan.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, please try again.");
            }
            scan.nextLine();
            switch (choice) {
                case 1:
                    ProgramManagement.programmeMenu();
                    break;
                case 2:
                    TutorialManagement.showTutorialMenu();
                    break;
                
                default:
                    TARUMTManagement tarumtMaintenance = new TARUMTManagement();
                    tarumtMaintenance.runTutorMaintenance();
                    break;
            }
        } while (choice != 3);
    
}
}



   