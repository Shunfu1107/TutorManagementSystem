/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;

import adt.LinkedList;
import adt.ListInterface;
import control.TutorController;
import dao.TutorDAO;
import entity.Tutor;
import java.util.Scanner;

/**
 *
 * @author yeeyung
 */
public class tutorManagementUI {
    private ListInterface<Tutor> tutorList = new LinkedList<>();
    private final static TutorDAO tutorDao = new TutorDAO();
        public tutorManagementUI() {
        tutorList = tutorDao.retrieveFromFile();
    }
        public void runTutorMaintenance() {
        int choice;
                
        String cont;

        do {

            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t\tTARUMT\t\t\t\t\t       |");
            System.out.println("|\t\t\t\tTutor Management Subsystem\t\t\t       |");
            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t\tMenu\t\t\t\t\t       |");
            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t1. Add New Tutor\t\t\t\t       |");
            System.out.println("|\t\t\t\t2. Remove A Tutor\t\t\t\t       |");
            System.out.println("|\t\t\t\t3. Find The Tutor\t\t\t\t       |");
            System.out.println("|\t\t\t\t4. Amend Tutor Details\t\t\t\t       |");
            System.out.println("|\t\t\t\t5. List All Tutor\t\t\t\t       |");
            System.out.println("|\t\t\t\t6. Filter The Tutor\t\t\t\t       |");
            System.out.println("|\t\t\t\t7. Generate Statistics Report\t\t\t       |");
            System.out.println("|\t\t\t\t8. Generate Working Report\t\t\t       |");
            System.out.println("|\t\t\t\t0. to Exit\t\t\t\t\t       |");

            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.print("Please select your choice(1-8):");
            Scanner sc = new Scanner(System.in);
            choice = Integer.parseInt(sc.nextLine());

            do {
                switch (choice) {
                    case 0:
                       TARUMTManagement tarumtMaintenance = new TARUMTManagement();
                       tarumtMaintenance.runTutorMaintenance();
                        break;  

                    case 1:
                        TutorController.add(tutorList);
                        break;

                    case 2:
                        TutorController.delete(tutorList);
                        break;

                    case 3:
                        TutorController.search(tutorList);
                        break;

                    case 4:
                        TutorController.amend(tutorList);
                        break;

                    case 5:
                        TutorController.listAllByTutor(tutorList);
                        break;
                        
                    case 6:
                        TutorController.filter(tutorList);
                        break;
                        
                    case 7:
                        TutorController.statisticsReport(tutorList);
                        break;  
                        
                    case 8:
                        TutorController.workingReport(tutorList);
                        break; 
                        
                    default:
                        System.out.print("Error please enter again: ");
                        choice = Integer.parseInt(sc.nextLine());
                                

                }
            } while (choice < 0 || choice > 8);

            System.out.println("\nContinue? (Y/N):");
            cont = sc.nextLine();

        }  while ("Y".equalsIgnoreCase(cont));
    }
        public static void main(String[] args) {
            tutorManagementUI tutorMaintenance = new tutorManagementUI();
            tutorMaintenance.runTutorMaintenance();
        }
}
