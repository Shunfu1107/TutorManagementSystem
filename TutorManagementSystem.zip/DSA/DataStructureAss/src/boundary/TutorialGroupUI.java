/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;

import dao.TutorialGroupDAO;
import adt.*;
import control.TutorialGroupController;
import entity.*;
import java.util.Scanner;

/**
 *
 * @author Chiew
 */
public class TutorialGroupUI {
    private final static TutorialGroupDAO tutorialGroupDAO = new TutorialGroupDAO();
    private ListInterface<TutorialGroup> tutorialGroup = new LinkedList<>();
    private Scanner scanner = new Scanner(System.in);
    TutorialGroupController controller = new TutorialGroupController();;
    
    public TutorialGroupUI() {
    tutorialGroup = tutorialGroupDAO.retrieveFromFile();
    }     
    
    public void TutorialGroupDriver(){
        boolean exit = false;

        while (!exit) {
            System.out.println("Main Menu:");
            System.out.println("1. Add Student to Tutorial Group");
            System.out.println("2. Remove Student from Tutorial Group");
            System.out.println("3. Change Tutorial Group for a Student");
            System.out.println("4. Find a student in a tutorial Group");
            System.out.println("5. List Students in a Tutorial Group");
            System.out.println("6. Filter tutorial groups based on criteria");
            System.out.println("7. Generate Reports");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    controller.addStudentToTutorialGroup(tutorialGroup);
                    break;
                case 2:
                    controller.removeStudentFromTutorialGroup(tutorialGroup);
                    break;
                case 3:
                    controller.changeTutorialGroupForStudent(tutorialGroup);
                    break;
                case 4:
                    controller.findStudentInTutorialGroup(tutorialGroup);
                    break;
                case 5:
                   
                    controller.listStudentsInTutorialGroup(tutorialGroup);
                    break;
                case 6:
                    controller.filterTutorialGroups(tutorialGroup);
                  
                    break;
                case 7:
                    controller.generateReports(tutorialGroup);
                    break;
                case 8:
                    TARUMTManagement tarumtMaintenance = new TARUMTManagement();
            tarumtMaintenance.runTutorMaintenance();
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }

        scanner.close();
}
    public static void main(String[] args) {
         TutorialGroupUI tutorialGroupUI = new TutorialGroupUI();
         tutorialGroupUI.TutorialGroupDriver(); 
    }
}










