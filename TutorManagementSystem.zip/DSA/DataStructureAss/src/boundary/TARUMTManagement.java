/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;

import control.AssignmentTeamManagementSystem;
import static java.lang.System.exit;
import java.util.Scanner;

/**
 *
 * @author ONGYEEYUNG,SiaShuFu,LohJianWei,ChiewChinChong
 */

public class TARUMTManagement {
    public void runTutorMaintenance() {
        int choice;
                
        String cont;

        do {

            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t\tTARUMT\t\t\t\t\t       |");
            System.out.println("|\t\t\t\tTARUMT Management System\t\t\t       |");
            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t\tMenu\t\t\t\t\t       |");
            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.println("|\t\t\t\t1. Tutorial Group Management Subsystem\t\t       |");
            System.out.println("|\t\t\t\t2. Programme Management Subsytem\t\t       |");
            System.out.println("|\t\t\t\t3. Tutor Management Subsystem\t\t\t       |");
            System.out.println("|\t\t\t\t4. Assignment Team Management Subsystem\t\t       |");
            System.out.println("|\t\t\t\t0. to Exit\t\t\t\t\t       |");

            System.out.println("|-------------------------------------------------"
                    + "-------------------------------------|");
            System.out.print("Please select your choice(1-4):");
            Scanner sc = new Scanner(System.in);
            choice = Integer.parseInt(sc.nextLine());

            do {
                switch (choice) {
                    case 0:
                       exit(0);
                        break;  

                    case 1:
                         TutorialGroupUI tutorialGroupUI = new TutorialGroupUI();
                         tutorialGroupUI.TutorialGroupDriver(); 
                        break;

                    case 2:
                        ProgrammeMain shuMain = new ProgrammeMain();
                        shuMain.startUI();
                        break;

                    case 3:
                        tutorManagementUI tutorMaintenance = new tutorManagementUI();
                        tutorMaintenance.runTutorMaintenance();
                        break;

                    case 4:
                        AssignmentTeamManagementSystem AssignmentTeamManagementSystem = new AssignmentTeamManagementSystem();
                        AssignmentTeamManagementSystem.startAssignmentTeamManagementSystem();
                        break;
                        
                    default:
                        System.out.print("Error please enter again: ");
                        choice = Integer.parseInt(sc.nextLine());
                                

                }
            } while (choice < 0 || choice > 4);

            System.out.println("\nBack to the main system? (Y/N):");
            cont = sc.nextLine();

        }  while ("Y".equalsIgnoreCase(cont));
    }
        public static void main(String[] args) {
            TARUMTManagement tarumtMaintenance = new TARUMTManagement();
            tarumtMaintenance.runTutorMaintenance();
        }
}

