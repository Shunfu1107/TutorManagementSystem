/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author Chiew Chin Chong
 */
public class TutorialGroup implements Comparable<TutorialGroup>, Serializable {

    private String group;
    private String programme;
    private List<Student> students;

    public TutorialGroup() {
    }

    public TutorialGroup(String group, String programme) {
        this.group = group;
        this.programme = programme;
        this.students = new ArrayList<>();
    }

    public TutorialGroup(List<Student> students) {
        this.students = students;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getProgramme() {
        return programme;
    }

    public void setProgramme(String programme) {
        this.programme = programme;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public void addStudent(Student student) {
        student.setTutorialGroup(this); // Set the tutorialGroup reference in the student
        students.add(student);
    }

    public Student searchStudent(String studentIDToFind) {
        if (students != null) {
            for (Student student : students) {
                if (student.getStudentID().equals(studentIDToFind)) {
                    return student; // Student found
                }
            }
        }
        return null; // Student not found
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.group);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TutorialGroup other = (TutorialGroup) obj;
        return Objects.equals(this.group, other.group);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Tutorial Group Information:\n");
        sb.append("Group: ").append(group).append("\n");
        sb.append("Programme: ").append(programme).append("\n");

        // Create a map to group students by their tutorial group
        Map<String, List<Student>> studentsByGroup = new HashMap<>();

        // Group students by tutorial group
        for (Student student : students) {
            String groupID = student.getTutorialGroup().getGroup();
            studentsByGroup.computeIfAbsent(groupID, k -> new ArrayList<>()).add(student);
        }

        // Print student information grouped by tutorial group
        sb.append("Students:\n");
        for (Map.Entry<String, List<Student>> entry : studentsByGroup.entrySet()) {
            String groupID = entry.getKey();
            List<Student> groupStudents = entry.getValue();

            sb.append("- Group ").append(groupID).append(":\n");
            for (Student student : groupStudents) {
                sb.append("  - ").append(student.getStudentID()).append(": ").append(student.getName()).append("\n");
            }
        }

        return sb.toString();
    }

    @Override
    public int compareTo(TutorialGroup otherGroup) {
        // Implement your comparison logic here
        // You can compare based on group name, for example
        return this.group.compareTo(otherGroup.group);
    }

}
