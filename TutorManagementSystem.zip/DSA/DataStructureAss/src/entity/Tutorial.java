package entity;

//author SiaShunFu
import java.util.Objects;



public class Tutorial implements Comparable<Tutorial>{


    private static int latestID = 1;
    private String code;
    private String program;
    private int number;

    public Tutorial(String code, String program) {
       
        this.code = code;
        this.number = 0;
        this.program = program;
    }
    public Tutorial(String code, int number, String program){

        this.code = code;
        this.number = number;
        this.program = program;
    }
 
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int age) {
        this.number = age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tutorial that = (Tutorial) o;
        return Objects.equals(code, that.code) ;
    }

    @Override
    public int compareTo(Tutorial c) {
        return this.code.compareTo(c.code);
    }


    @Override
    public String toString() {return "Code: " + code;}

    
    public int getNumberOfEntries() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
