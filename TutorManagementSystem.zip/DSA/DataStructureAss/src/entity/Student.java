/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;

/**
 *
 * @author Chiew Chin Chong
 */
public class Student implements Comparable<Student>, Serializable {
    private String studentID;
    private String name;
    private TutorialGroup tutorialGroup;

    public Student(String studentID, String name) {
        this.studentID = studentID;
        this.name = name;
    }

    public Student(String studentID) {
        this.studentID = studentID;
    }

    
    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TutorialGroup getTutorialGroup() {
        return tutorialGroup;
    }

    public void setTutorialGroup(TutorialGroup tutorialGroup) {
        this.tutorialGroup = tutorialGroup;
    }
 
    @Override
    public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("- ").append(studentID).append(" (").append(name).append(")\n");
    return sb.toString();
}

    @Override
    public int compareTo(Student otherStudent) {
        // Compare student IDs
        return this.studentID.compareTo(otherStudent.studentID);
    }

    Student get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

}
