/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Objects;
//import utility.InterfaceFilter;
//import model.Semester.FilterSemester;

/**
 *
 * @author ONGYEEYUNG
 */
public class Tutor implements Comparable<Tutor> , Serializable{
    private Semester mester;
    private String id;
    private String name;
    private String gender;
    private String email;
    private String pNumber;
    private String position;
    private String course;
    private String type;
    private double payroll;
   
    
    public Tutor() {
    }

    
    public Tutor(String id) {
        this.id = id;
    }

    public Tutor(Semester mester, String id, String name, String gender, String email, String pNumber, String position, String course, String type,double payroll) {
        this.mester = mester;
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.email = email;
        this.pNumber = pNumber;
        this.position = position;
        this.course = course;
        this.type = type;
        this.payroll=payroll;
    }    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Semester getMester() {
        return mester;
    }

    public void setMester(Semester mester) {
        this.mester = mester;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getpNumber() {
        return pNumber;
    }

    public void setpNumber(String pNumber) {
        this.pNumber = pNumber;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPayroll() {
        return payroll;
    }

    public void setPayroll(double payroll) {
        this.payroll = payroll;
    }

    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tutor other = (Tutor) obj;
        return Objects.equals(this.id, other.id);
    }


    @Override
    public String toString() {
        return String.format("%-10s %-8s %-18s %-8s %-25s %-13s %-12s %-13s %-9s %.2f",mester,id, name ,gender , email , pNumber , position ,course ,type ,payroll);
    }
    

    public Tutor(Semester mester, String position, String type) {
        this.mester = mester;
        this.position = position;
        this.type = type;
    }
    

    public boolean matches(Tutor element){

    return position.equals(element.getPosition()) && type.equals(element.getType()) && mester.getName().equals(element.getMester().getName());
    }
    @Override
    public int compareTo(Tutor o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
}
