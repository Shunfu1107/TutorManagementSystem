/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import adt.LinkedList;
import dao.TutorDAO;
import entity.Semester;
import entity.Tutor;
import java.util.Iterator;
import java.util.Scanner;
import adt.ListInterface;

/**
 *
 * @author ONGYEEYUNG
 */
public class TutorController {
    private final static TutorDAO tutorDao = new TutorDAO();
    
    public static void listAllByTutor(ListInterface<Tutor> tutorList) {
        System.out.println("\nTutor List:\n" );
        System.out.printf("%-10s %-6s %-8s %-18s %-8s %-25s %-13s %-12s %-9s %-13s %s\n" , "Semester" , 
                "SemID"   , "TutorId" ,"Name" ,"Gender" , "Email" , "Phone" , 
                "Position" ,"Course" , "Work Type" ,"Salary(RM)");
        System.out.println("===================================================================================="
                + "=========================================================");
         Iterator<Tutor> iterator = tutorList.iterator();
    while (iterator.hasNext()) {
        Tutor tutor = iterator.next();
        System.out.println(tutor);
    } 
    }
    
    public static void search(ListInterface<Tutor> tutorList) {
    Scanner sc = new Scanner(System.in);

    boolean found = false;

    while (!found) {
        System.out.println("\nSearhing Tutor details:" );
        System.out.print("Enter Tutor ID (or 'q' / 'Q' to quit): ");
        String id = sc.nextLine();

         if (id.equalsIgnoreCase("q")) {
            break;  
        }
         
        Tutor foundTutor = tutorList.search(new Tutor(id));
    

        if (foundTutor != null) {
            System.out.println("Found Tutor:");
            System.out.printf("%-8s %-17s %-10s %-15s %-28s %-15s %-10s %-13s %s\n", "TutorId", "Name", 
                    "Gender", "Phone", "Email","Position", "Course", "Work Type" ,"Salary(RM)");
                    System.out.println("===================================================================================="
                + "==================================================");
            System.out.printf("%-8s %-17s %-10s %-15s %-28s %-15s %-14s %-9s %.2f\n", foundTutor.getId(), foundTutor.getName(), foundTutor.getGender(),
                    foundTutor.getpNumber(), foundTutor.getEmail(), foundTutor.getPosition(), foundTutor.getCourse(), foundTutor.getType(),foundTutor.getPayroll());
        } else {
            System.out.println("Tutor not found. Please try again.\n");
        }
    }
}
    public static void filter(ListInterface<Tutor> tutorList) {
    LinkedList<Tutor> result = new LinkedList<>();
    boolean found = false;
    Scanner sc = new Scanner(System.in);
 
    while(!found){
    System.out.println("\nEnter the tutor details to filter\n");
    
    System.out.print("Enter the semester name (Long Sem / Short Sem): ");
    String semName = sc.nextLine();
    
    System.out.print("Enter the tutor position (Lecturer/Tutor): ");
    String position = sc.nextLine();
    
    System.out.print("Enter the working type (F=Full, P=Past): ");
    String type = sc.nextLine();

    if (semName.isEmpty()) {
        semName = null;
    }
    
    if (position.isEmpty()) {
        position = null;
    }
    
    if (type.isEmpty()) {
        type = null;
    }

    Tutor filter = new Tutor(semName != null ? new Semester(semName) : null, position, type);

    Iterator<Tutor> it = tutorList.iterator();

    while (it.hasNext()) {
        Tutor currentTutor = it.next();
        if (currentTutor.matches(filter)) {
            result.add(currentTutor);
        }
    }

    if (result.isEmpty()) {
        System.out.println("No matching tutors found.\n");
    } else {
        System.out.printf("%-10s %-6s %-8s %-18s %-8s %-25s %-13s %-12s %-9s %-13s %s\n" , "Semester" , 
                "SemID"   , "TutorId" ,"Name" ,"Gender" , "Email" , "Phone" , 
                "Position" ,"Course" , "Work Type" ,"Salary(RM)");
        System.out.println("===================================================================================="
                + "=======================================================");
         System.out.println(result.toString());
         found=true;
        }
    }
    }

    
    public static void add(ListInterface<Tutor> tutorList){
        
        String semName, semId, tutorId, name, gender, email, phone, position, course, type;
        double payroll;
    
         Scanner scanner = new Scanner(System.in);
         System.out.println("Add the tutor details\n");
         System.out.print("Enter the semester name eg(Long Sem , Short Sem):");
         semName = scanner.nextLine();
         
         System.out.print("Enter the semester id (RSD/RIT/RIS):");
         semId = scanner.nextLine();
         
         System.out.print("Enter tutuor id:");
         tutorId = scanner.nextLine();
         
         System.out.print("Enter tutor name:");
         name = scanner.nextLine();
         
         System.out.print("Enter gender:");
         gender = scanner.nextLine();
         
         System.out.print("Enter tutor email:");
         email = scanner.nextLine();
         
         System.out.print("Enter tutor contact number:");
         phone = scanner.nextLine();
         
         System.out.print("Enter tutor position (Lecturer / Tutor):");
         position = scanner.nextLine();
         
         System.out.print("Enter teaching course:");
         course = scanner.nextLine();
         
         System.out.print("Enter working type ( F = Full , P = Past):");
         type = scanner.nextLine();
         
         System.out.print("Enter payroll(RM):");
         payroll = scanner.nextDouble();
         
         Tutor newTutor = new Tutor(new Semester(semName,semId),tutorId, name, gender, email,phone,position,course,type,payroll);
         
        if (!tutorList.contains(newTutor)) {
        tutorList.add(newTutor);
        System.out.println("Tutor added successfully!");
        tutorDao.saveToFile(tutorList);
        } else {
        System.out.println("Tutor ID already exists. Please enter a different ID.");
       
         
    }
    }
    
    
    public static void delete(ListInterface<Tutor> tutorList){
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Remove the tutor details\n");
        System.out.print("Enter tutor id:");
        String tutorId = scan.nextLine();
        if(tutorList.remove(new Tutor(tutorId))){
            System.out.println("Delete successfully!");
            tutorDao.saveToFile(tutorList);
        }
        else{
            System.out.println("Tutor with ID " + tutorId + " not found.");
        }
        
    }
    
    public static void amend(ListInterface<Tutor> tutorList){
        
    Scanner scan = new Scanner(System.in);
    System.out.println("Amend the tutor details\n");
    System.out.print("Enter tutor id:");
    String tutorId = scan.nextLine();

    Tutor tutorToUpdate = tutorList.search(new Tutor(tutorId));

    if (tutorToUpdate != null) {
        System.out.println("Tutor found. Enter the new details:");

        System.out.print("Enter new name:");
        String newName = scan.nextLine();
        tutorToUpdate.setName(newName);

        System.out.print("Enter new gender:");
        String newGender = scan.nextLine();
        tutorToUpdate.setGender(newGender);

        System.out.print("Enter new email:");
        String newEmail = scan.nextLine();
        tutorToUpdate.setEmail(newEmail);

        System.out.print("Enter new phone:");
        String newPhone = scan.nextLine();
        tutorToUpdate.setpNumber(newPhone);

        System.out.print("Enter new position (Lecturer / Tutor):");
        String newPosition = scan.nextLine();
        tutorToUpdate.setPosition(newPosition);

        System.out.print("Enter new course:");
        String newCourse = scan.nextLine();
        tutorToUpdate.setCourse(newCourse);

        System.out.print("Enter new work type (F=Full, P=Past):");
        String newType = scan.nextLine();
        tutorToUpdate.setType(newType);
        
        System.out.print("Enter new payroll (RM):");
        double payroll = scan.nextDouble();
        tutorToUpdate.setPayroll(payroll);

        System.out.println("Tutor details updated successfully!");
        tutorDao.saveToFile(tutorList);
    } else {
        System.out.println("Tutor with ID " + tutorId + " not found.");
    }
}
    
    public static void statisticsReport(ListInterface<Tutor> tutorList) {
    System.out.println("\nStatistics Report\n");
        System.out.printf("%-10s %-6s %-8s %-18s %-8s %-25s %-13s %-12s %-9s %-13s %s\n" , "Semester" , 
                "SemID"   , "TutorId" ,"Name" ,"Gender" , "Email" , "Phone" , 
                "Position" ,"Course" , "Work Type" ,"Salary(RM)");
    System.out.println("===================================================================================="
                + "=======================================================");
    int totalTutors = tutorList.getNumberOfEntries();
    double totalSalaries = 0;
    double averageSalary = 0;
    double highestSalary = Double.MIN_VALUE;
    double lowestSalary = Double.MAX_VALUE;

    int maleTutors = 0;
    int femaleTutors = 0;

    Iterator<Tutor> it = tutorList.iterator();
    while (it.hasNext()) {
        Tutor currentTutor = it.next();
        double tutorSalary = currentTutor.getPayroll();
        totalSalaries += tutorSalary;

        if (tutorSalary > highestSalary) {
            highestSalary = tutorSalary;
        }

        if (tutorSalary < lowestSalary) {
            lowestSalary = tutorSalary;
        }

        String gender = currentTutor.getGender();
        if (gender.equalsIgnoreCase("Male")) {
            maleTutors++;
        } else if (gender.equalsIgnoreCase("Female")) {
            femaleTutors++;
        }

       if (totalTutors > 0) {
        averageSalary = totalSalaries / totalTutors;
       }

        
    }

     Iterator<Tutor> iterator = tutorList.iterator();
    while (iterator.hasNext()) {
        Tutor tutor = iterator.next();
        System.out.println(tutor);
    }
    System.out.println("===================================================================================="
                + "=======================================================");

    System.out.printf("|%105s Total Tutors       : %d %8s\n" , "", totalTutors,"|");
    System.out.printf("|%105s Male Tutors        : %d %8s\n" , "", maleTutors," |");
    System.out.printf("|%105s Female Tutors      : %d %8s\n" , "", femaleTutors,"|");
    System.out.printf("|%105s Average Salary (RM): %.2f %3s\n" , "",averageSalary,"|");
    System.out.printf("|%105s Highest Salary (RM): %.2f %3s\n" ,"", highestSalary,"|");
    System.out.printf("|%105s Lowest Salary  (RM): %.2f %4s\n" , "",lowestSalary,"|");
    
    System.out.println("===================================================================================="
                + "=======================================================");
}
    
    public static void workingReport(ListInterface<Tutor> tutorList){
    System.out.println("\nTotal Working Report\n");
        System.out.printf("%-10s %-6s %-8s %-18s %-8s %-25s %-13s %-12s %-9s %-13s %s\n" , "Semester" , 
                "SemID"   , "TutorId" ,"Name" ,"Gender" , "Email" , "Phone" , 
                "Position" ,"Course" , "Work Type" ,"Salary(RM)");
    System.out.println("===================================================================================="
                + "=======================================================");
    int totalTutors = tutorList.getNumberOfEntries();
    int maleTutors = 0;
    int femaleTutors = 0;
    int pastTime = 0;
    int fullTime = 0;
    int numOfLecturer =0;
    int numOfTutor =0;
    Iterator<Tutor> it = tutorList.iterator();
    while (it.hasNext()) {
        Tutor currentTutor = it.next();

        String gender = currentTutor.getGender();
        if (gender.equalsIgnoreCase("Male")) {
            maleTutors++;
        } else if (gender.equalsIgnoreCase("Female")) {
            femaleTutors++;
        }
        
        String workingType = currentTutor.getType();
        if (workingType.equalsIgnoreCase("F")) {
            fullTime++;
        } else if (workingType.equalsIgnoreCase("P")) {
            pastTime++;
        }

        String position = currentTutor.getPosition();
         if (position.equalsIgnoreCase("Lecturer")) {
            numOfLecturer++;
        } else if (position.equalsIgnoreCase("Tutor")) {
            numOfTutor++;
        }
    }
    
    Iterator<Tutor> iterator = tutorList.iterator();
    while (iterator.hasNext()) {
        Tutor tutor = iterator.next();
        System.out.println(tutor);
    }
    System.out.println("===================================================================================="
                + "=======================================================");
    System.out.printf("|%100s Total Tutors and Lecturer  : %d  %4s\n" , "", totalTutors,"|");
    System.out.printf("|%100s Total Lecturer             : %d %5s\n" , "", numOfLecturer,"|");
    System.out.printf("|%100s Total Tutors               : %d %5s\n" , "", numOfTutor,"|");
    System.out.printf("|%100s Male Tutors                : %d %5s\n" , "", maleTutors,"|");
    System.out.printf("|%100s Female Tutors              : %d %5s\n" , "", femaleTutors,"|");
    System.out.printf("|%100s Full Time Tutors           : %d %5s\n" , "",fullTime,"|");
    System.out.printf("|%100s Past Time Tutors           : %d %6s\n" ,"", pastTime,"|");
    
    System.out.println("===================================================================================="
                + "=======================================================");
    }
}

