package control;
//author Sia Shun Fu

import adt.ArrList;
import adt.ArraySortedSetList;
import static control.ProgramManagement.displayAllTutorialForProgramme;
import static control.ProgramManagement.displayProgrammeList;
import static control.ProgramManagement.programLinkedList;
import static control.ProgramManagement.scanner;
import entity.Programme;
import entity.Tutorial;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class TutorialManagement {

    public static void clearConsole() {
        // Clears the command line
        // Only works on Windows command line, doesn't work in Netbeans IDE command line and
        // Intellij IDEA Ultimate Command Line
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception E) {
            System.out.println(E);
        }
    }
    public static Scanner scan = new Scanner(System.in);
    public static ArrList<String, Tutorial> TutorialTable = new ArrList<String, Tutorial>();

    public static void showTutorialMenu() {
        int choice = 0;
        do {
//            clearConsole();
            System.out.println("+-------------------------+");
            System.out.println("| Tutorial Management Menu |");
            System.out.println("+-------------------------+");
            System.out.println("1. Add Tutorial to Programme");
            System.out.println("2. Remove Tutorial Group From Programme");
            System.out.println("3. Back");
            System.out.print("Enter your choice: ");
            choice = scan.nextInt();
            scan.nextLine();
            switch (choice) {
                case 1:
                    addTutorialToProgram();
                    break;
                case 2:
                    removeTutorialGroupFromProgramme();
                    break;
                case 3:
                default:
                    break;
            }
        } while (choice != 3);

    }

    public static void addTutorialToProgram() {
        if (TutorialTable.getNumberOfEntries() == 0) {
            System.out.println("No Tutorial Group to add to Program...");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
        if (ProgramManagement.programLinkedList.getNumberOfEntries() == 0) {
            System.out.println("No Tutorial Group to add Program to");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
//        clearConsole();
        System.out.println("+------------------------------------+");
        System.out.println("| Add Tutorial Group to Program Menu |");
        System.out.println("+------------------------------------+");
        showTutorialList();
        Tutorial group = null;
        do {
            System.out.print("Enter Tutorial Group (-1 to go back): ");
            String input = scan.nextLine();
            if (input.compareTo("-1") == 0) {
                return;
            }
            group = parseTutorialInput(input);
            if (group == null) {
                System.out.println("Invalid Tutorial Group!!");
            }
        } while (group == null);

        int tutorialIndex = 0;
        do {
            ProgramManagement.showProgrammeList();
            System.out.println("Enter Program Code to add Tutorial Group: ");
            try {
                tutorialIndex = scan.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Input is not a Number. Please try again.");
                continue;
            }
            if (tutorialIndex < 1 || tutorialIndex > ProgramManagement.programLinkedList.getNumberOfEntries()) {
                System.out.println("Invalid Program Code...Please Try Again");
                System.out.println("Press any key to continue");
                scan.nextLine();
            }
        } while (tutorialIndex < 1 || tutorialIndex > ProgramManagement.programLinkedList.getNumberOfEntries());
        scan.nextLine();
        ProgramManagement.programLinkedList.getEntry(tutorialIndex - 1).addTutorial(group);
    }

    public static void showTutorialList() {
        Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
        int index = 0;
        while (tutorialIterator.hasNext()) {
            Tutorial group = tutorialIterator.next();
            System.out.println((index + 1) + ". " + group.getCode());
            index++;
        }
    }

    public static Tutorial parseTutorialInput(String input) {
        if (input.matches("[0-9]+")) {
            if (Integer.parseInt(input) > 0 && Integer.parseInt(input) <= TutorialTable.getNumberOfEntries()) {
                return getTutorial(Integer.parseInt(input));
            } else {
                return null;
            }
        } else {
            return getTutorial(input);
        }
    }

    /**
     * @param index, index is 1-based, not 0
     * @return Tutorial Object if found, null otherwise
     */
    public static Tutorial getTutorial(int index) {
        if (index > 0 && index <= TutorialTable.getNumberOfEntries()) {
            Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
            for (int i = 1; i < index; i++) {
                tutorialIterator.next();
            }
            return tutorialIterator.next();
        }
        return null;
    }

    public static Tutorial getTutorial(String name) {
        // ListInterface.retrieve returns null if not found
        return TutorialTable.retrieve(name);
    }

    private static void removeTutorialGroupFromProgramme() {

        if (TutorialTable.getNumberOfEntries() == 0) {
            System.out.println("No Tutorial Group to add to Program...");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
        if (ProgramManagement.programLinkedList.getNumberOfEntries() == 0) {
            System.out.println("No Tutorial Group to add Program to");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
//        clearConsole();
        System.out.println("+------------------------------------+");
        System.out.println("| Remove Tutorial Group to Program Menu |");
        System.out.println("+------------------------------------+");
        displayProgrammeList();
        int positionToRemove = -1;
        boolean isValidInput = false;
        while (!isValidInput) {
            System.out.println("\nEnter position Programme to remove Tutorial Group: (or -1 to exit)");
            String input = scanner.nextLine();
            if (input.equals("-1")) {
                break; // Exit case statement
            }
            try {

                positionToRemove = Integer.parseInt(input);
                if (positionToRemove < 1 || positionToRemove > programLinkedList.getSize()) {
                    System.out.println("Invalid input. Please enter a number between 1 and " + programLinkedList.getSize() + ".");
                } else {
                    isValidInput = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        if (positionToRemove != -1) {
            Programme programme = programLinkedList.getEntry(positionToRemove - 1);
// Proceed only if user didn't enter -1

            if (programLinkedList.contains(programme)) {
                int position = programLinkedList.getPosition(programme);
                Programme searchedProgramme = programLinkedList.getEntry(position);

                System.out.println("\nProgramme details:");
                System.out.println(searchedProgramme.toString());
//                    programLinkedList = searchedProgramme.getProgrammeList();

                ArrList<String, Tutorial> tutorialList = new ArrList<String, Tutorial>();

                Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
                while (tutorialIterator.hasNext()) {
                    Tutorial group = tutorialIterator.next();
                    if (group.getProgram().equals(programme.getCode())) {
                        tutorialList.put(group.getCode(), group);

                    }
                }

                if (tutorialList.getNumberOfEntries() != 0) {
                    System.out.println("+------------------------------------+");
                    System.out.println("|       Select a Tutorial Group      |");
                    System.out.println("+------------------------------------+");
                    Iterator<Tutorial> availableTutIT = tutorialList.getIterator();
                    int index = 0;
                    String[] codeArr = new String[20];
                    while (availableTutIT.hasNext()) {
                        Tutorial group = availableTutIT.next();

                        System.out.println((index + 1) + ". " + group.getCode());
                        codeArr[index++] = group.getCode();
                    }

                    int positionToRemove2 = -1;
                    boolean isValidInput2 = false;
                    while (!isValidInput2) {
                        System.out.println("\nEnter position to remove Tutorial Group: (or -1 to exit)");
                        String input = scanner.nextLine();
                        if (input.equals("-1")) {
                            break; // Exit case statement
                        }
                        try {
                            positionToRemove2 = Integer.parseInt(input);
                            if (positionToRemove2 < 1 || positionToRemove2 > tutorialList.getNumberOfEntries()) {
                                System.out.println("Invalid input. Please enter a number between 1 and " + tutorialList.getNumberOfEntries() + ".");
                            } else {
                                isValidInput2 = true;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter a number.");
                        }
                    }

                    if (positionToRemove2 != -1) {
                        programme.removeTutorial(TutorialTable.retrieve(codeArr[positionToRemove2 - 1]));
                    }
                }

            }

        }

    }
}
