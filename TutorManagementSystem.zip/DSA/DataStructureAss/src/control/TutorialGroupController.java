/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

/**
 *
 * @author Chiew Chin Chong
 */
import dao.TutorialGroupDAO;
import adt.*;
import entity.*;
import java.util.*;
import java.util.function.Predicate;

public class TutorialGroupController {

    private final static TutorialGroupDAO tutorialGroupDAO = new TutorialGroupDAO();
    Scanner scanner = new Scanner(System.in);

    public void addStudentToTutorialGroup(ListInterface<TutorialGroup> tutorialGroups) {
        System.out.println("List of Tutorial Groups:");
        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.get(i);
            System.out.println((i + 1) + ": " + group.getGroup() + " - " + group.getProgramme());
        }

        System.out.print("Enter the index of the Tutorial Group: ");
        int groupIndex = scanner.nextInt();
        scanner.nextLine();

        if (groupIndex >= 1 && groupIndex <= tutorialGroups.getNumberOfEntries()) {
            TutorialGroup selectedGroup = tutorialGroups.search(groupIndex - 1);

            System.out.print("Enter Student ID: ");
            String studentID = scanner.nextLine();

            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine();

            Student newStudent = new Student(studentID, name);

            selectedGroup.addStudent(newStudent);

            System.out.println("Student successfully added to the tutorial group.\n");

            tutorialGroupDAO.saveToFile(tutorialGroups);

        } else {
            System.out.println("Invalid group index. Please enter a valid index.");
        }

    }

    public void removeStudentFromTutorialGroup(ListInterface<TutorialGroup> tutorialGroups) {

        System.out.println("List of Tutorial Groups:");
        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            System.out.println((i + 1) + ": " + tutorialGroups.search(i));
        }

        System.out.print("Enter the index of the Tutorial Group: ");
        int groupIndex = scanner.nextInt();
        scanner.nextLine();

        if (groupIndex >= 1 && groupIndex <= tutorialGroups.getNumberOfEntries()) {
            TutorialGroup selectedGroup = tutorialGroups.search(groupIndex - 1);

            System.out.print("Enter the Student ID to remove from Group " + selectedGroup.getGroup() + ": ");
            String studentIDToRemove = scanner.nextLine();

            List<Student> students = selectedGroup.getStudents();
            boolean studentRemoved = false;

            Iterator<Student> iterator = students.iterator();
            while (iterator.hasNext()) {
                Student student = iterator.next();
                if (student.getStudentID().equals(studentIDToRemove)) {
                    iterator.remove();
                    studentRemoved = true;
                    break;
                }
            }

            if (studentRemoved) {
                System.out.println("Student successfully removed from Group " + selectedGroup.getGroup());
            } else {
                System.out.println("Student with ID " + studentIDToRemove + " not found in Group " + selectedGroup.getGroup());
            }


            TutorialGroupDAO tutorialGroupDAO = new TutorialGroupDAO();
            tutorialGroupDAO.saveToFile(tutorialGroups);
        } else {
            System.out.println("Invalid group index. Please enter a valid index.");
        }
    }

    public void changeTutorialGroupForStudent(ListInterface<TutorialGroup> tutorialGroups) {
        System.out.println("Enter the student details to change tutorial group");

        System.out.print("Enter the student's ID: ");
        String studentIDToChange = scanner.nextLine();
        Student studentToChange = null;
        TutorialGroup currentGroup = null;

        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.search(i);
            Student student = group.searchStudent(studentIDToChange);

            if (student != null) {
                studentToChange = student;
                currentGroup = group;
                break;
            }
        }

        if (studentToChange != null) {
            System.out.println("List of Tutorial Groups:");
            for (int j = 0; j < tutorialGroups.getNumberOfEntries(); j++) {
                TutorialGroup availableGroup = tutorialGroups.search(j);
                System.out.println((j + 1) + ": " + availableGroup.getGroup() + " - " + availableGroup.getProgramme());
            }

            System.out.print("Enter the new tutorial group index: ");
            int newGroupIndex = scanner.nextInt();
            scanner.nextLine();

            if (newGroupIndex >= 1 && newGroupIndex <= tutorialGroups.getNumberOfEntries()) {
                TutorialGroup newTutorialGroup = tutorialGroups.search(newGroupIndex - 1);

                currentGroup.getStudents().remove(studentToChange);
                newTutorialGroup.getStudents().add(studentToChange);

                studentToChange.setTutorialGroup(newTutorialGroup);

                System.out.println("Student moved to the new tutorial group successfully.\n");


                tutorialGroupDAO.saveToFile(tutorialGroups);
            } else {
                System.out.println("Invalid tutorial group index.");
            }
        } else {
            System.out.println("Student not found.");
        }
    }

    public void findStudentInTutorialGroup(ListInterface<TutorialGroup> tutorialGroup) {

        System.out.println("List of Tutorial Groups:");
        for (int i = 0; i < tutorialGroup.getNumberOfEntries(); i++) {
            System.out.println((i + 1) + ": " + tutorialGroup.search(i));
        }

        System.out.print("Enter the index of the tutorial group: ");
        int groupIndex = scanner.nextInt();

        groupIndex--;

        if (groupIndex >= 0 && groupIndex < tutorialGroup.getNumberOfEntries()) {
            scanner.nextLine();
            TutorialGroup selectedGroup = tutorialGroup.search(groupIndex);

            System.out.print("Enter the Student ID to find in the selected group: ");
            String studentIDToFind = scanner.nextLine();

            Student foundStudent = selectedGroup.searchStudent(studentIDToFind);

            if (foundStudent != null) {
                System.out.println("Student found in the selected group: " + foundStudent);
            } else {
                System.out.println("Student not found in the selected group.");
            }
        } else {
            System.out.println("Invalid group index. Please enter a valid index.");
        }
    }

    public void listStudentsInTutorialGroup(ListInterface<TutorialGroup> tutorialGroups) {

        System.out.println("List of Tutorial Groups:");
        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.get(i);
            System.out.println((i + 1) + ": " + group.getGroup() + " - " + group.getProgramme());
        }

        System.out.print("Enter the index of the tutorial group: ");
        int groupIndex = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        groupIndex--;

        if (groupIndex >= 0 && groupIndex < tutorialGroups.getNumberOfEntries()) {

            TutorialGroup selectedGroup = tutorialGroups.get(groupIndex);

            List<Student> studentsInGroup = selectedGroup.getStudents();

            System.out.println("\nStudents in " + selectedGroup.getGroup() + " group: ");

            for (Student student : studentsInGroup) {
                System.out.println("- " + student.getStudentID() + "(" + student.getName() + ")");
            }
        } else {
            System.out.println("Invalid group index. Please enter a valid index.");
        }
    }

    public void filterTutorialGroups(ListInterface<TutorialGroup> tutorialGroups) {
        Set<String> programNames = new HashSet<>();

        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.get(i);
            String program = group.getProgramme();
            if (program != null) {
                programNames.add(program);
            }
        }

        System.out.println("Available Programmes:");
        for (String program : programNames) {
            System.out.println(program);
        }

        System.out.print("Enter program name to filter by: ");
        String programName = scanner.nextLine();

        Predicate<TutorialGroup> filterFunction = group
                -> group.getProgramme() != null && group.getProgramme().equalsIgnoreCase(programName);

        List<TutorialGroup> filteredGroups = new ArrayList<>();
        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.get(i);
            if (filterFunction.test(group)) {
                filteredGroups.add(group);
            }
        }

        // Display the filtered groups
        System.out.println("\nFiltered Tutorial Groups:");
        for (int i = 0; i < filteredGroups.size(); i++) {
            TutorialGroup group = filteredGroups.get(i);
            System.out.println((i + 1) + ": " + group.getGroup() + " - " + group.getProgramme() + "\n");
        }
    }

    public void generateReports(ListInterface<TutorialGroup> tutorialGroups) {
        Map<String, Integer> studentCountByProgramme = new HashMap<>();

        for (int i = 0; i < tutorialGroups.getNumberOfEntries(); i++) {
            TutorialGroup group = tutorialGroups.get(i);
            List<Student> students = group.getStudents();

            String programme = group.getProgramme();
            int studentCount = (students != null) ? students.size() : 0;
            studentCountByProgramme.put(programme, studentCount + studentCountByProgramme.getOrDefault(programme, 0));
        }

        System.out.println("\nTotal Students in a Particular Programme Report:");
        for (Map.Entry<String, Integer> entry : studentCountByProgramme.entrySet()) {
            String programme = entry.getKey();
            int totalStudentCount = entry.getValue();
            System.out.println("Programme: " + programme + " - " + totalStudentCount + " students\n");
        }
    }

}
