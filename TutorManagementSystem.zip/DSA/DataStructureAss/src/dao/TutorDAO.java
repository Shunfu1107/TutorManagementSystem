/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author ONGYEEYUNG
 */
import adt.LinkedList;
import java.io.*;
import entity.Tutor;
import adt.ListInterface;

public class TutorDAO {

//    private final String fileName = "C:\\Users\\User\\Downloads\\tutor.dat"; // 文件名
    private final String fileName = "tutor.dat"; // 文件名
    // 保存数据到文件
    public void saveToFile(ListInterface<Tutor> tutorList) {
    try {
        try (ObjectOutputStream ooStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            ooStream.writeObject(tutorList);
        }
        System.out.println("Data saved successfully to " + fileName);
    } catch (FileNotFoundException ex) {
        System.out.println("Error: File not found - " + ex.getMessage());
    } catch (IOException ex) {
        System.out.println("Error: Cannot save to file - " + ex.getMessage());
    } catch (Exception ex) {
        System.out.println("Error: An unexpected error occurred - " + ex.getMessage());
    }
}
    
        // 从文件中检索数据
    public ListInterface<Tutor> retrieveFromFile() {
        LinkedList<Tutor> tutorList = new LinkedList<>();
        try {
            ObjectInputStream oiStream = new ObjectInputStream(new FileInputStream(fileName));
            tutorList = (LinkedList<Tutor>) (oiStream.readObject());
            oiStream.close();
        } catch (FileNotFoundException ex) {
            System.out.println("\nFile not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("\nCannot read from file: " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("\nClass not found: " + ex.getMessage());
        }
        return tutorList;
    }
}


