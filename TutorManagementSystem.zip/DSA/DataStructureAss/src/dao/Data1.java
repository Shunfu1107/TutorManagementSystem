package dao;


import Data.*;
import adt.*;
import entity.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chiew Chin Chong
 */
public class Data1 {
    public static void main(String[] args) {
       
        ListInterface<TutorialGroup> tutorialGroup = new LinkedList<>();          
    
        TutorialGroup groupA = new TutorialGroup("RSDG1", "Information Technology");
        TutorialGroup groupB = new TutorialGroup("RSDG2", "Information Technology");
    
        TutorialGroup groupC = new TutorialGroup("RCSG1", "Computer Science");
        TutorialGroup groupD = new TutorialGroup("RCSG2", "Computer Science");
        
        
        groupA.addStudent(new Student("RSDA1","Ali"));
        groupA.addStudent(new Student("RSDA2", "Edward"));
        groupA.addStudent(new Student("RSDA3", "Eugenio"));
        groupA.addStudent(new Student("RSDA4", "Galahad"));
        groupA.addStudent(new Student("RSDA5", "Ron"));
        groupA.addStudent(new Student("RSDA6", "Parris"));
        groupA.addStudent(new Student("RSDA7", "Laci"));
        groupA.addStudent(new Student("RSDA8", "Marisa"));
        groupA.addStudent(new Student("RSDA9", "Laraine"));
        groupA.addStudent(new Student("RSDA10", "Pete"));
        
        groupB.addStudent(new Student("RSDB1", "Zoe"));
        groupB.addStudent(new Student("RSDB2", "Tad"));
        groupB.addStudent(new Student("RSDB3", "Caiden"));
        groupB.addStudent(new Student("RSDB4", "Windsor"));
        groupB.addStudent(new Student("RSDB5", "Wynonna"));
        groupB.addStudent(new Student("RSDB6", "Sabella"));
        groupB.addStudent(new Student("RSDB7", "Minerva"));
        groupB.addStudent(new Student("RSDB8", "Seanna"));
        groupB.addStudent(new Student("RSDB10", "Avianna"));
        
        groupC.addStudent(new Student("RCSA1", "Kirk"));
        groupC.addStudent(new Student("RCSA2", "Niki"));
        groupC.addStudent(new Student("RCSA3", "Floyd"));
        groupC.addStudent(new Student("RCSA4", "Berry"));
        groupC.addStudent(new Student("RCSA5", "Moss"));
        groupC.addStudent(new Student("RCSA6", "Gallagher"));
        groupC.addStudent(new Student("RCSA7", "Marcy"));
        groupC.addStudent(new Student("RCSA8", "Primula"));
        groupC.addStudent(new Student("RCSA9", "Brandee"));
        groupC.addStudent(new Student("RCSA10", "Charlie"));
        
        groupD.addStudent(new Student("RCSB1", "Monroe"));
        groupD.addStudent(new Student("RCSB2", "Hepsie"));
        groupD.addStudent(new Student("RCSB3", "Linette"));
        groupD.addStudent(new Student("RCSB4", "Farley"));
        groupD.addStudent(new Student("RCSB5", "Aileen"));
        groupD.addStudent(new Student("RCSB6", "Chyna"));
        groupD.addStudent(new Student("RCSB7", "Isebella"));
        groupD.addStudent(new Student("RCSB8", "Leanna"));
        groupD.addStudent(new Student("RCSB9", "Lachlan"));
        groupD.addStudent(new Student("RCSB10", "David"));
        
        tutorialGroup.add(groupA);
        tutorialGroup.add(groupB);
        tutorialGroup.add(groupC);
        tutorialGroup.add(groupD);
        System.out.println(tutorialGroup);
        
        TutorialGroupDAO tutorialGroupDAO = new TutorialGroupDAO();
        tutorialGroupDAO.saveToFile(tutorialGroup);

    }
}
