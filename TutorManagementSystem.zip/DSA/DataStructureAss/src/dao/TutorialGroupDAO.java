/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import adt.LinkedList;
import adt.ListInterface;
import entity.TutorialGroup;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Chiew Chin Chong
 */
public class TutorialGroupDAO {
    private final String fileName = "TutorialGroup.dat";

    public void saveToFile(ListInterface<TutorialGroup> tutorialGroup) {
    try {
        try (ObjectOutputStream ooStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
            ooStream.writeObject(tutorialGroup);
        }
        System.out.println("Data saved successfully to " + fileName + "\n");
    } catch (FileNotFoundException ex) {
        System.out.println("Error: File not found - " + ex.getMessage());
    } catch (IOException ex) {
        System.out.println("Error: Cannot save to file - " + ex.getMessage());
    } catch (Exception ex) {
        System.out.println("Error: An unexpected error occurred - " + ex.getMessage());
    }
}
    
    public ListInterface<TutorialGroup> retrieveFromFile() {
       ListInterface<TutorialGroup> tutorialGroup= new LinkedList<>();
        try {
            ObjectInputStream oiStream = new ObjectInputStream(new FileInputStream(fileName));
            tutorialGroup = (LinkedList<TutorialGroup>) (oiStream.readObject());
            oiStream.close();
        } catch (FileNotFoundException ex) {
            System.out.println("\nFile not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("\nCannot read from file: " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("\nClass not found: " + ex.getMessage());
        }
        return tutorialGroup;
    }
}

