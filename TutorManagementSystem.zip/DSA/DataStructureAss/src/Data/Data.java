package Data;


import adt.LinkedList;
import dao.TutorDAO;
import entity.Semester;
import entity.Tutor;
import adt.ListInterface;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ONGYEEYUNG
 */
public class Data{
    public static void main(String[] args) {
        ListInterface<Semester> mester = new LinkedList<>();
        mester.add(new Semester("Long Sem","RSDS1"));
        mester.add(new Semester("Long Sem","RSTS1"));
        mester.add(new Semester("Long Sem","RISS1"));
        
        mester.add(new Semester("Short Sem","RSDS2"));
        mester.add(new Semester("Short Sem","RSTS2"));
        mester.add(new Semester("Short Sem","RSTS2"));
        
        mester.add(new Semester("Long Sem","RSDS3"));
        mester.add(new Semester("Long Sem","RSTS3"));
        mester.add(new Semester("Long Sem","RISS3"));
        
    ListInterface<Tutor> tutorList = new LinkedList<>();
    tutorList.add(new Tutor(mester.get(0),"A001","Shoong Wai Kin","Male","shoongwaikin.tarc.edu.my","015-3456890","Lecturer","AACS1074","F",1200.00));
    tutorList.add(new Tutor(mester.get(0),"A002","Kathleen Tan","Female","kathleenTan.tarc.edu.my","010-2554978","Tutor","BACS2063","F",1500.00));
    tutorList.add(new Tutor(mester.get(1),"A003","Lee Kim Keong","Male","p334.tarc.edu.my","011-2226890","Tutor","BACS2053","P",4000.00));
    tutorList.add(new Tutor(mester.get(1),"A004","Tin Tin Ting","Female","p212.tarc.edu.my","012-5168909","Lecturer","BACS2053","P",1500.00));
    tutorList.add(new Tutor(mester.get(2),"A005","Lai Joo Choi","Male","joochoiLai.tarc.edu.my","012-3198901","Tutor","BAIT2203","F",7000.00));
    tutorList.add(new Tutor(mester.get(2),"B006","Kathleen Tan","Female","kathleenTan.tarc.edu.my","010-2554978","Tutor","BACS2063","F",4500.00));
    tutorList.add(new Tutor(mester.get(3),"B007","Lee Kim Ong","Male","p1334.tarc.edu.my","011-2226891","Tutor","BACS2053","P",5500.00));
    tutorList.add(new Tutor(mester.get(3),"B008","Tan Tan Tang","Female","p215.tarc.edu.my","012-5168109","Lecturer","BACS2053","P",800.00));
    tutorList.add(new Tutor(mester.get(4),"B009","Fong Yee Lee","Female","p1245.tarc.edu.my","012-3148801","Lecturer","BACS2042","P",1000.00));
    tutorList.add(new Tutor(mester.get(4),"B010","Lee Keng Xian","Male","p1457.tarc.edu.my","012-3107901","Tutor","AMIT3904","P",1500.00));
    tutorList.add(new Tutor(mester.get(5),"C011","Pong Suk Fun","Female","sukfunPong.tarc.edu.my","011-3198901","Tutor","AMIT3205","F",4500.00));
    tutorList.add(new Tutor(mester.get(5),"C012","Ong Mor Yang","Male","joochoiLai.tarc.edu.my","010-3198901","Tutor","AACS1443","F",4000.00));
    tutorList.add(new Tutor(mester.get(6),"C013","Chaw Tim Lam","Female","chawtimLam.tarc.edu.my","011-3128901","Lecturer","BAIT2004","F",6000.00));
    tutorList.add(new Tutor(mester.get(6),"C014","Tan Pei Ling","Female","peilingTan.tarc.edu.my","011-8950146","Lecturer","BAIT2104","F",4500.00));
    tutorList.add(new Tutor(mester.get(7),"C015","Choon Kwai Mui","Female","kwaimuiChoon.tarc.edu.my","013-8951789","Tutor","BAIT2009","F",1500.00));
    tutorList.add(new Tutor(mester.get(7),"D016","Tan Lai Kien","Female","laikienTan.tarc.edu.my","015-1937825","Lecturer","BAIT2051","F",1500.00));
    tutorList.add(new Tutor(mester.get(8),"D017","Aw Kien Sin","Male","sinkienAw.tarc.edu.my","016-9782456","Lecturer","BAIT2287","F",1500.00));
    tutorList.add(new Tutor(mester.get(8),"D018","Too Wei Chin","Female","weichinToo.tarc.edu.my","012-1782526","Tutor","BAIT2987","F",1500.00));
    tutorList.add(new Tutor(mester.get(8),"D019","Too Jiao Yang","Male","jiaoyangToo.tarc.edu.my","012-1145268","Tutor","BAIT2981","F",450.00));
    tutorList.add(new Tutor(mester.get(8),"D020","Too Wen Ting","Female","tingToo.tarc.edu.my","012-2648192","Lecturer","BAIT2984","F",1500.00));


    
       TutorDAO tutorDAO = new TutorDAO();

       tutorDAO.saveToFile(tutorList);
            
    }
}
