/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package adt;

import java.util.Iterator;


/**
 *
 * @author ONGYEEYUNG  (Chiew Chin Chong add the changeObject)
 */
public interface ListInterface<T extends Comparable<T>> {
    public void add(int index, T data); //1
    public boolean add(T t);  //2
    public boolean remove(Object o); //3
    public void remove(int index);  //4
    public T search(int index); //5
    public T search(T anElement);  //6
    public void clear();  //7
    public Object[] toArray();  //8
    public boolean isEmpty();  //9
    public int getNumberOfEntries();  //10
    public void changeObject(Object targetO, Object o);//14 Cc
    public T get(int index);  //11
    public boolean contains(T data);  //12
    Iterator<T> iterator();  //13
}
