   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adt;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author ONGYEEYUNG
 * @param <T>
 */
public class LinkedList<T extends Comparable<T>> implements ListInterface<T> ,Serializable{

    private int numberOfEntries = 0;
    private Node head;
    private Node tail;

    @Override
    public void add(int index, T data) {
        checkPositionIndex(index);
    /* 
         * The cases:
         * 1. An empty linked list,
         * 2. The head (before the current first item) of the linked list, i = 0,
         * 3. The position beyond the last (the current tail) item of the linked list, i = N,
         * 4. The other positions of the linked list, i = [1..N-1].
         * 5. The numberOfEntries plus one.
         */
        if (numberOfEntries == 0) {
            insertNew(data);
        } else if (index == 0) {
            insertHead(data);
        } else if (index == numberOfEntries) {
            insertTail(data);
        } else {
            insertMiddle(data,index);
        }
        
        numberOfEntries++;
    }

    @Override
    public void remove(int index) {
         checkElementIndex(index);
         
        /*
         * For remove(i), there are three (legal) possibilities, i.e. index i is:
         *
         * The head (the current first item) of the linked list, i = 0, it affects the head pointer
         * The tail of the linked list, i = N-1, it affects the tail pointer
         * The other positions of the linked list, i = [1..N-2].
         */
        if (index == 0) {
            removeHead();
        } else if (index == numberOfEntries - 1) {
            removeTail();
        } else {
            removeMiddle(node(index));
        }
    }
    @Override
    public T search(int index) {
    checkElementIndex(index);
    Node<T> node = node(index);
//    if (node != null) {
//        System.out.println("Node value at index " + index + ": " + node.data);
        return node.data;
//    } else {
//        System.out.println("Node at index " + index + " is null.");
//        return null;
//    }
}

    @Override
    public T search(T anElement) {
        int index = indexOf(anElement);
        if(index == -1){
            return null;
        }
        return node(index).data;
    }

    private Node<T> node(int index) {
    // If index is under half part of the list, loop from head
        // Else loop from tail.
        // Best case O(1)
        // Worst case O(n)
    if (index < numberOfEntries) {
        Node node = head;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        return node;
    }  else {
        Node node = tail;
            for (int i = numberOfEntries - 1; i > index; i--) {
                node = node.prev;
            }
            return node;
    }
    }
    
    public int indexOf(Object o) {
        int index = 0;
        for (Node x = head; x != null; x = x.next) {
            if (o.equals(x.data)) {
                return index;
            }
            index++;
        }
        return -1;
    }

    @Override
    public void clear() {
        // Clearing all of the links between nodes is "unnecessary", but:
        // - helps a generational GC if the discarded nodes inhabit
        //   more than one generation
        // - is sure to free memory even if there is a reachable Iterator
        Node temp = head;
        while (temp != null) {
            Node next = temp.next;
            temp.data = null;
            temp.next = null;
            temp.prev = null;
            temp = next;
        }

        head = null;
        tail = null;
        numberOfEntries = 0;
    }
    
    @Override
    public boolean add(T t){
       if (tail != null) {
            insertTail(t);
        } else {
            insertNew(t);
        }
        return true;
    }
    
    @Override
    public boolean remove(Object o) {
         int index = indexOf(o);
         if (index == -1) {
         return false;
         }
        remove(index);
        return true;
    }
    
    @Override
    public Object[] toArray(){
        Object[] array = new Object[numberOfEntries];
        int i = 0;
        for (Node node = head;
                node != null;
                node = node.next) {
            array[i++] = node.data;
        }
        return array;
    }
    
    @Override
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }

    @Override
    public int getNumberOfEntries() {
          return numberOfEntries;
        }
   /*
     * Tells if the argument is the index of an existing element.
     */
    private void checkElementIndex(int index) {
        if (!(index >= 0 && index < numberOfEntries)) {
        throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
        }
    }

    /*
     * Tells if the argument is the index of a valid position for an iterator or
     * an add operation.
     */
    private void checkPositionIndex(int index) {
        if (!(index >= 0 && index <= numberOfEntries)) {
        throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
        }
    }

    /*
     * Constructs an IndexOutOfBoundsException detail message.
     */
    private String outOfBoundsMsg(int index) {
        return "Index: " + index + ", Size: " + numberOfEntries;
    }

   private void insertNew(T data) {
        // Create a new node
        Node node = new Node(null,data,null);

        // New head and tail of the list
        head = node;
        tail = node;

        numberOfEntries++;
    }

    private void insertHead(T data) {
        // Create a new node, with it's next points to the old head.
        Node node = new Node(null,data, head);

        // New head of the list
        head = node;

        numberOfEntries++;
    }

    private void insertTail(T data) {
        // Create a new node, with it's next points to the old tail.
        Node node = new Node(tail,data,null);

        // Update old tail next
        tail.next = node;

        // New tail of the list
        tail = node;

        numberOfEntries++;
    }

    private void insertMiddle(T data, int index) {
    checkPositionIndex(index);

    Node nodeBefore = node(index - 1);

    if (nodeBefore != null) {
     Node<T> node = new Node<>(nodeBefore, data, nodeBefore.next);

      if (nodeBefore.next != null) {
         nodeBefore.next.prev = node;
      }

        nodeBefore.next = node;

        numberOfEntries++;
    } else {
        Node node = new Node<>(null, data, head);
        if (head != null) {
            head.prev = node;
        }
        head = node;

        numberOfEntries++;
    }
}

    private void removeHead() {
        // Temporary store the head
        Node oldHead = head;

        // Transfer the head
        head = oldHead.next;
         head.prev = null;

        // Help garbage collection
        // oldHead.prev = null; // head's prev is already a null
        oldHead.data = null;
        oldHead.next = null;

        numberOfEntries--;
    }
    
    private void removeTail() {
    if (tail == null) {
        return; // Empty list, nothing to remove
    }

    if (head == tail) {
        head = null;
        tail = null;
    } else {
        Node newTail = tail.prev;
        newTail.next = null;
        tail.prev = null;
        tail.data = null;
        tail = newTail;
    }
    numberOfEntries--;
}
    
    private void removeMiddle(Node node) {
    // Temporary store the previous and next nodes
    Node prevNode = node.prev;
    Node nextNode = node.next;

    // Update the next node's previous reference
    if (nextNode != null) {
        nextNode.prev = prevNode;
    }

    // Update the previous node's next reference
    if (prevNode != null) {
        prevNode.next = nextNode;
    }

    // Help garbage collection
    node.prev = null;
    node.data = null;
    node.next = null;

    numberOfEntries--;
}

    @Override
    public T get(int index) {
    checkElementIndex(index); 
    return node(index).data;
}

    @Override
    public void changeObject(Object targetObject, Object newGroup) {
    Node<T> current = head;

    while (current != null) {
        if (current.data.equals(targetObject)) {
            // Found the target object, change its group to newGroup
            current.data = (T) newGroup;
            return; // Exit the method once the object is found and updated
        }
        current = current.next;
    }

    // If the target object is not found, you can handle this case as needed.
    System.out.println("Object not found.");
}
    
   private static class Node<T> implements Serializable {

    T data;
    private Node next;
    private Node prev;

    Node(Node prev,T data, Node next) {
      this.data = data;
      this.next = next;
      this.prev = prev;
    }
  }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node node = head;
        while(node != null) {
            sb.append(node.data.toString());
            sb.append('\n');
            node = node.next;
        }
        return sb.toString();
    }
 
    @Override
    public Iterator<T> iterator() {
        return new TutorLinkedIterator();
    }
    
    private class TutorLinkedIterator implements Iterator<T> {
        private Node<T> lastReturned;
        private Node next;
        private int nextIndex;

        TutorLinkedIterator() {
            next = head;
            nextIndex = 0;
        }

        @Override
        public boolean hasNext() {
            return nextIndex < numberOfEntries;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            lastReturned = next;
            next = next.next;
            nextIndex++;
            return lastReturned.data;
        }
    }
    @Override
    public boolean contains(T data) {
    Node<T> current = head;

    while (current != null) {
        if (current.data.equals(data)) {
            return true; 
        }
        current = current.next;
    }
    return false; 
}
}