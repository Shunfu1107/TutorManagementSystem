﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MelodySpa
{
    public partial class Service : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }




        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "BOOK")
            {

                int index = Convert.ToInt32(e.CommandArgument);
             
                int serviceID = Convert.ToInt32(GridView2.DataKeys[index]["serviceID"].ToString());


                
               

                Session["service"] = serviceID;
                Response.Redirect("Booking.aspx");

            }



        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}