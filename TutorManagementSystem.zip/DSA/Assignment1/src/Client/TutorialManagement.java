package Client;

import ADT.ArrayList;

import static Client.ProgramManagement.displayAllTutorialForProgramme;
import static Client.ProgramManagement.displayProgrammeList;
import static Client.ProgramManagement.programLinkedList;
import static Client.ProgramManagement.scanner;
import Entities.Programme;
import Entities.Tutorial;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class TutorialManagement {
    public static void clearConsole() {
        // Clears the command line
        // Only works on Windows command line, doesn't work in Netbeans IDE command line and
        // Intellij IDEA Ultimate Command Line
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception E) {
            System.out.println(E);
        }
    }
    public static Scanner scan = new Scanner(System.in);
    public static ArrayList<String, Tutorial> TutorialTable = new ArrayList<String, Tutorial>();

    public static void showTutorialMenu(){
        int choice = 0;
        do {
            clearConsole();
            System.out.println("+-------------------------+");
            System.out.println("| Tutorial Management Menu |");
            System.out.println("+-------------------------+");
            System.out.println("1. Add Tutorial");
            System.out.println("2. Remove Tutorial");
            System.out.println("3. View Tutorial");
            System.out.println("4. Add Tutorial to Programme");
            System.out.println("5. Remove Tutorial Group From Programme");
            System.out.println("6. Back");
            System.out.print("Enter your choice: ");
            choice = scan.nextInt();
            scan.nextLine();
            switch (choice){
                case 1:
                    addTutorial();
                    break;
                case 2:
                    removeTutorial();
                    break;
                case 3:
                    displayTutorial();
                    break;
                case 4:
                    addTutorialToProgram();
                    break;
                case 5:
                    removeTutorialGroupFromProgramme();
                    break;
                case 6:
                default:
                    break;
            }
        } while(choice !=6);
        
    }

        public static void addTutorial() {
        clearConsole();
        System.out.println("+-------------------+");
        System.out.println("| Add Tutorial Menu |");
        System.out.println("+-------------------+");
        Tutorial group = null;
        boolean isValidInput = false;
        String Group;
        do{
            System.out.print("Enter Tutorial Group (-1 to Cancel): ");
            Group = scan.nextLine();
            try{
                // Attempts parsing it as Number and check whether it matches the value -1
                // if the name passes as a number, ask user to input again
                int aNumber = Integer.parseInt(Group);
                if(aNumber == -1){
                    return;
                }
                System.out.println("Tutorial Group cannot be empty!");
                continue;
            }catch(NumberFormatException ignored){
            }

            // duplicate group check
            group = TutorialTable.retrieve(Group);
            if(group != null){
                System.out.println(String.format("Tutorial Group %s already exists. Please use another tutorial group.", Group));
            } else {
                isValidInput = true;
            }
        } while(isValidInput == false);

        isValidInput = false;
        String program;
        do{
            System.out.print("Enter Tutorial Program (-1 to Cancel): ");
            program = scan.nextLine();
            try{
                // Attempts parsing it as Number and check whether it matches the value -1
                // if the name passes as a number, ask user to input again
                int aNumber = Integer.parseInt(program);
                if(aNumber == -1){
                    return;
                }
                System.out.println("Tutorial Group cannot be empty!");
                continue;
            }catch(NumberFormatException ignored){
            }

            // duplicate group check
            group = TutorialTable.retrieve(program);
            if(group != null){
                System.out.println(String.format("Tutorial Group %s already exists. Please use another tutorial group.", program));
            } else {
                isValidInput = true;
            }
        } while(isValidInput == false);

        isValidInput = false;
        int number = 1;
        do{
            System.out.print("Enter Tutorial Group Number of Student : ");
            try{
                number = scan.nextInt();
                if(number < 1) {
                    System.out.println("Tutorial Group Number of Student cannot be lesser than 1");
                } else if(number > 99){
                    System.out.println("Tutorial Group Number of Student cannot be more than 99");
                } else {
                    isValidInput = true;
                }
            }catch(InputMismatchException e){
                System.out.println("Tutorial Group Number of Student must be a number!");
            }
        } while(isValidInput == false);
        TutorialTable.put(Group, new Tutorial(Group, number, program));
    }
        
        public static void removeTutorial(){
        if(TutorialTable.getNumberOfEntries() == 0){
            System.out.println("No Tutorial Group found in database...Returning to Tutorial Management Menu");
            System.out.println("Press any key To Continue...");
            scan.nextLine();
            return;
        }
        clearConsole();
        System.out.println("+----------------------+");
        System.out.println("| Remove Tutorial Menu |");
        System.out.println("+----------------------+");
        showTutorialList();
        Tutorial group;
        do {
            System.out.print("Enter Tutorial Group to Remove (-1 to go back): ");
            String input = scan.nextLine();
            if(input.compareTo("-1") == 0){
                return;
            }
            group = parseTutorialInput(input);
            if(group == null){
                System.out.println("Invalid Tutorial Group!!");
            }
        } while (group == null);
        TutorialTable.remove(group.getCode());
        System.out.println(String.format("Tutorial Group with the name %s has been successfully removed", group.getCode()));
        System.out.println("Press any key To Continue...");
        scan.nextLine();
    }


    public static void displayTutorial() {
        if(TutorialTable.getNumberOfEntries() == 0){
            System.out.println("No Tutorial Group to view...");
        } else {
            clearConsole();
            System.out.println("+--------------------+");
            System.out.println("| View Tutorial Menu |");
            System.out.println("+--------------------+\n");
            Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
            int index = 0;
            while(tutorialIterator.hasNext()){
                Tutorial group = tutorialIterator.next();
                System.out.println("Tutorial Group : " + group.getCode());
                System.out.println("Program        : " + group.getProgram());
                System.out.println("NumberOfStudent: " + group.getNumber()+ " people \n");
                 
                index++;
            }
        }
        System.out.println("Press Enter to Continue");
        scan.nextLine();
    }

    public static void addTutorialToProgram() {
        if(TutorialTable.getNumberOfEntries() == 0){
            System.out.println("No Tutorial Group to add to Program...");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
        if(ProgramManagement.programLinkedList.getNumberOfEntries() == 0){
            System.out.println("No Tutorial Group to add Program to");
            System.out.println("Returning to Tutorial Management Menu");
            System.out.println("Press any key to continue...");
            scan.nextLine();
            return;
        }
        clearConsole();
        System.out.println("+------------------------------------+");
        System.out.println("| Add Tutorial Group to Program Menu |");
        System.out.println("+------------------------------------+");
        showTutorialList();
        Tutorial group = null;
        do {
            System.out.print("Enter Tutorial Group (-1 to go back): ");
            String input = scan.nextLine();
            if(input.compareTo("-1") == 0){
                return;
            }
            group = parseTutorialInput(input);
            if(group == null){
                System.out.println("Invalid Tutorial Group!!");
            }
        } while (group == null);

        int tutorialIndex = 0;
        do {
            ProgramManagement.showProgrammeList();
            System.out.println("Enter Program Code to add Tutorial Group to (-1 to go back): ");
            try{
                tutorialIndex = scan.nextInt();
            } catch(InputMismatchException e){
                System.out.println("Input is not a Number. Please try again.");
                continue;
            }
            if(tutorialIndex < 1 || tutorialIndex > ProgramManagement.programLinkedList.getNumberOfEntries()){
                System.out.println("Invalid Program Code...Please Try Again");
                System.out.println("Press any key to continue");
                scan.nextLine();
            }
        } while(tutorialIndex < 1 || tutorialIndex > ProgramManagement.programLinkedList.getNumberOfEntries());
        scan.nextLine();
        ProgramManagement.programLinkedList.getEntry(tutorialIndex - 1).addTutorial(group);
    }
    
    public static void showTutorialList(){
        Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
        int index = 0;
        while(tutorialIterator.hasNext()){
            Tutorial group = tutorialIterator.next();
            System.out.println((index + 1) + ". " + group.getCode());
            index++;
        }
    }
    
    
    public static Tutorial parseTutorialInput(String input){
        if(input.matches("[0-9]+")){
            if(Integer.parseInt(input) > 0 && Integer.parseInt(input) <= TutorialTable.getNumberOfEntries()){
                return getTutorial(Integer.parseInt(input));
            }
            else{
                return null;
            }
        } else {
            return getTutorial(input);
        }
    }

    /**
     * @param index, index is 1-based, not 0
     * @return Tutorial Object if found, null otherwise
     */
    public static Tutorial getTutorial(int index) {
        if(index > 0 && index <= TutorialTable.getNumberOfEntries()){
            Iterator<Tutorial> tutorialIterator = TutorialTable.getIterator();
            for(int i = 1; i < index; i++){
                tutorialIterator.next();
            }
            return tutorialIterator.next();
        }
        return null;
    }


    public static Tutorial getTutorial(String name){
        // ListInterface.retrieve returns null if not found
        return TutorialTable.retrieve(name);
    }

      private static void removeTutorialGroupFromProgramme() {


//          System.out.println("List of Programme :");
//  
//        for (int i = 0; i < programLinkedList.getNumberOfEntries(); i++) {
//            System.out.println((i + 1) + ": " + programLinkedList.getEntry(i));
//        }
//
//        System.out.print("Enter the index of the Programme : ");
//        int programmeIndex = scanner.nextInt();
//        scanner.nextLine();
//
//        if (programmeIndex >= 1 && programmeIndex <= programLinkedList.getNumberOfEntries()) {
//            Programme selectedProgramme = programLinkedList.getEntry(programmeIndex - 1);
//
//            System.out.print("Enter the Tutorial Group to remove from Programme : " );
//            String tutorialGroupToRemove = scanner.nextLine();
//
//            List<TutorialTable> TutorialTable =  selectedProgramme.displayAllTutorialForProgramme();
//            boolean tutorialRemoved = false;
//
//            Iterator<TutorialTable> iterator = TutorialTable.getIterator();
//            while (iterator.hasNext()) {
//                TutorialManagement tutorial = iterator.next();
//                if (TutorialTable.getIterator().equals(tutorialGroupToRemove)) {
//                    iterator.remove();
//                    tutorialRemoved = true;
//                    break;
//                }
//            }
//
//            if (tutorialRemoved) {
//                System.out.println("Tutorial successfully removed from Programme " + programLinkedList.getSize());
//            } else {
//                System.out.println("Tutorial  " + tutorialGroupToRemove + " not found in Group " + programLinkedList.getSize());
//            }
//
//            System.out.println("\nUpdated List of Programme Groups: ");
//            for (int i = 0; i < programLinkedList.getNumberOfEntries(); i++) {
//                System.out.println((i + 1) + ": " + programLinkedList.getEntry(i));
//            }
//
//     
//        } else {
//            System.out.println("Invalid group index. Please enter a valid index.");
//        }
    }












  }


