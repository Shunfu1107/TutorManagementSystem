package Client;

import ADT.ArraySortedSetList;
import Entities.Programme;
import Entities.Tutorial;

import java.util.InputMismatchException;
import java.util.Scanner;
import ADT.SortedListInterface;


public class ProgramManagement {

    public static ArraySortedSetList<Programme> programLinkedList = new ArraySortedSetList<Programme>();
    static Scanner scanner = new Scanner(System.in);

  

    private static String promptForValidInput(String prompt) {
        String input;
        do {
            System.out.print(prompt);
            input = scanner.nextLine();
            if (!input.equalsIgnoreCase("Y") && !input.equalsIgnoreCase("N")) {
                System.out.println("Invalid input. Please enter Y or N:");
            }
        } while (!input.equalsIgnoreCase("Y") && !input.equalsIgnoreCase("N"));
        return input;
    }

    public static void programmeMenu(){
        while (true) {
            System.out.println("\nWelcome to the Programme Management Subsystem");
            System.out.println("1. Add a new Programme");
            System.out.println("2. Remove a Programme");
            System.out.println("3. Clear Programme List");
            System.out.println("4. Find Programme");
            System.out.println("5. Amend Programme details");
            System.out.println("6. List all Programme");
            System.out.println("7. List Tutorial Groups For A Programme");
            System.out.println("8. Generate Report");
            System.out.println("9. Back");
            System.out.println("Enter your choice:");
            int choice = 0;

            // Validate choice input
            while (true) {
                try {
                    choice = scanner.nextInt();
                    if (choice < 1 || choice > 9) {
                        throw new InputMismatchException();
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number from 1 to 9.");
                    scanner.nextLine();
                }
            }
            scanner.nextLine();
            switch (choice) {
                case 1: //Choose which option to add Programme
                    addProgramme();
                    break;
                case 2:// Remove Programme
                    removeProgramme();
                    break;
                case 3:// Clear Programme list
                    clearProgramme();
                    break;
                case 4:// Search Programme
                    searchProgramme();
                    break;
                case 5: // Update Programme
                    updateProgramme();
                    break;
                case 6: // Display Programme list
                    displayProgrammeList();  
                    break;             
                case 7:
                    displayAllTutorialForProgramme();
                    break;
                case 8:
                    generateReport();
                    break;
                case 9:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter  1 to 9 only. \n");
                    break;
            }
        }
    }

    public static void addProgramme(){
        int addOption = 0;
        while (true) {
            System.out.println("\n1. Add Programme");
            System.out.println("2. Back");
            System.out.println("Enter your choice: ");
            try {
                addOption = scanner.nextInt();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.nextLine(); // consume the remaining input
            }
        }
        scanner.nextLine(); // consume the newline character left by nextInt()
        switch (addOption) {
            case 1:// Add Programme
                System.out.println("\nEnter Programme Code: (or -1 to exit)");
                String code = scanner.nextLine();

                // Validate code input
                while (code.isEmpty()) {
                    System.out.println("Invalid input. Please enter a valid string.");
                    code = scanner.nextLine();
                }

                // Allow user to go back to menu if they enter -1
                if (code.equals("-1")) {
                    break;
                }

                System.out.println("\nEnter Programme Name: (or -1 to exit)");
                String name = scanner.nextLine();

                // Validate code input
                while (name.isEmpty()) {
                    System.out.println("Invalid input. Please enter a valid string.");
                    code = scanner.nextLine();
                }

                // Allow user to go back to menu if they enter -1
                if (code.equals("-1")) {
                    break;
                }
                
                
                System.out.println("\nEnter Programme Leader: (or -1 to exit)");
                String leader = scanner.nextLine();

                // Validate code input
                while (leader.isEmpty()) {
                    System.out.println("Invalid input. Please enter a valid string.");
                    code = scanner.nextLine();
                }

                // Allow user to go back to menu if they enter -1
                if (code.equals("-1")) {
                    break;
                }
                Programme subject = new Programme(code, name, leader);


                System.out.println("Are you sure you want to add this Programme? (Y/N)");

                String confirmAdd = promptForValidInput("");

                if (confirmAdd.equalsIgnoreCase("Y")) {
                    programLinkedList.add(subject);
                    System.out.println("Programme added successfully!\n");
                } else if (confirmAdd.equalsIgnoreCase("N")) {
                    System.out.println("Programme not added.\n");
                    break;
                }
                break;



            case 2:
                System.out.println("Exiting...\n");
                break;
            default:
                System.out.println("Invalid input. Please enter 1 or 2.\n");
                break;
        }
    }
    
    public static void removeProgramme(){
        if (programLinkedList.isEmpty()) {
            System.out.println("\nThe current list is empty, Please add new Programme first. (Y)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("y")) {
                return;
            } else {
                System.out.println("Exiting...\n");
            }
        } else {
            System.out.println("Current Programme List:\n");
            ProgramManagement.showProgrammeList();

            // Validate positionToRemove input
            int positionToRemove = -1;
            boolean isValidInput = false;
            while (!isValidInput) {
                System.out.println("\nEnter position of Programme to remove: (or -1 to exit)");
                String input = scanner.nextLine();
                if (input.equals("-1")) {
                    break; // Exit case statement
                }
                try {
                    positionToRemove = Integer.parseInt(input);
                    if (positionToRemove < 1 || positionToRemove > programLinkedList.getSize()) {
                        System.out.println("Invalid input. Please enter a number between 1 and " + programLinkedList.getSize() + ".");
                    } else {
                        isValidInput = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
            if (positionToRemove != -1) { // Proceed only if user didn't enter -1
                System.out.println("Select an option:");
                System.out.println("1. Remove Programme completely.");
                System.out.println("2. Back.");

                // Validate user input for selected option
                int selectedOption = 0;
                boolean isValidOption = false;
                while (!isValidOption) {
                    String input = scanner.nextLine();
                    try {
                        selectedOption = Integer.parseInt(input);
                        if (selectedOption == 1 || selectedOption == 2) {
                            isValidOption = true;
                        } else {
                            System.out.println("Invalid input. Please enter 1 or 2.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a number.");
                    }
                }

                String confirmRemove = "";
                if(selectedOption == 1){
                    System.out.println("Do you want to remove this Programme? (Y/N)");
                    confirmRemove = scanner.nextLine();
                }else{
                    return;
                }


                // Validate confirmRemove input
                while (!confirmRemove.equalsIgnoreCase("Y") && !confirmRemove.equalsIgnoreCase("N")) {
                    System.out.println("Invalid input. Please enter Y or N.");
                    confirmRemove = scanner.nextLine();
                }

                if (confirmRemove.equalsIgnoreCase("Y")) {
                    Programme programToRemove = programLinkedList.getEntry(positionToRemove - 1);
                    if (selectedOption == 1) {
                        programLinkedList.remove(positionToRemove - 1);
                        System.out.println("Programme successfully removed  !\n");
                    } else {
                       return;
                    }
                } else if (confirmRemove.equalsIgnoreCase("N")) {
                    System.out.println("Programme not removed.\n");
                }
            }
        }
    }

    public static void clearProgramme() {
        System.out.println("\nSelect an option:");
        System.out.println("1. Clear current Programme list.");
        System.out.println("2. Back");
        
        int selectedOption = 0;
        boolean isValidOption = false;
        while (!isValidOption) {
            String input = scanner.nextLine();
            try {
                selectedOption = Integer.parseInt(input);
                if (selectedOption == 1 || selectedOption == 2) {
                    isValidOption = true;
                } else {
                    System.out.println("Invalid input. Please enter 1 or 2.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        if (selectedOption == 1) {
            if (programLinkedList.isEmpty()) {
                System.out.println("\nThe current list is empty, Please add new programme first. (Y)");
                String response = scanner.nextLine();
                if (response.equalsIgnoreCase("y")) {
                    return;
                } else {
                    System.out.println("Exiting...\n");
                }
            } else {
                System.out.println("Current Programme List:\n");
                ProgramManagement.showProgrammeList();

                System.out.println("\nDo you want to clear the programme list? (Y/N)");
                String confirmClear = scanner.nextLine();

                // Validate confirmClear input
                while (!confirmClear.equalsIgnoreCase("Y") && !confirmClear.equalsIgnoreCase("N")) {
                    System.out.println("Invalid input. Please enter Y or N.");
                    confirmClear = scanner.nextLine();
                }

                if (confirmClear.equalsIgnoreCase("Y")) {
                    programLinkedList.clear();
                    System.out.println("Programme list successfully cleared  !\n");
                } else if (confirmClear.equalsIgnoreCase("N")) {
                    System.out.println("Programme list not cleared.\n");
                }
            }
        } else if (selectedOption == 2) {
            return;
        }
    }


    public static void searchProgramme() {
        boolean continueSearching = true;
        while (continueSearching) {
            // check if there are any Programme
            if (programLinkedList.isEmpty() ) {
                System.out.println("\nThe current list is empty, Please add new programme first. (Y)");
                String response = scanner.nextLine();
                if (response.equalsIgnoreCase("y")) {
                    return;
                } else {
                    System.out.println("Exiting...\n");
                    return;
                }
            }  else {
                
                System.out.println("\nEnter Programme code for search :  (-1 to exit)");
                String programCode = scanner.nextLine();
                if (programCode.equals("-1")) {
                    break;
                }

                Programme programme = new Programme(programCode, "", "");

                boolean programFound = false;
                ArraySortedSetList<Tutorial> programmeList = null;
                
                
 

                // check current Programme
                if (programLinkedList.contains(programme)) {
                    int position = programLinkedList.getPosition(programme);
                    Programme searchedProgramme = programLinkedList.getEntry(position);
                    System.out.println("\nThis is the Programme code that you search :   " + programCode);
                    System.out.println("\nProgramme details:");
                    System.out.println(searchedProgramme.toString());
                    programmeList = searchedProgramme.getProgrammeList();
                    programFound = true;
                }

   

                if (!programFound) {
                    System.out.println("\nThe Programme " + programCode + " does not exist");
                } else {
                    System.out.println("\nTutorial Group:");
                    showProgrammeList(programmeList);
                }

                boolean validInput = false;
                while (!validInput) {
                    System.out.println("Do you want to continue searching? (Y/N)");
                    String response = scanner.nextLine();
                    if (response.equalsIgnoreCase("n")) {
                        continueSearching = false;
                        validInput = true;
                    } else if (response.equalsIgnoreCase("y")) {
                        validInput = true;
                    } else {
                        System.out.println("Invalid input. Please enter Y or N.");
                    }
                }
            }
        }
    }

    public static void updateProgramme(){
        if (programLinkedList.isEmpty()) {
            System.out.println("\nThe current list is empty, Please add new Programme first. (Y)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("y")) {
                return;
            } else {
                System.out.println("Exiting...\n");
            }
        } else {
            System.out.println("Current Programme List:\n");
            ProgramManagement.showProgrammeList();

            int positionToUpdate = -1;
            do {
                System.out.println("\nEnter the number that u want to update: (or -1 to exit)");
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a valid integer:");
                    scanner.nextLine();
                }
                positionToUpdate = scanner.nextInt();
                scanner.nextLine(); // consume the newline character left by nextInt()
            } while (positionToUpdate != -1 && (positionToUpdate < 1 || positionToUpdate > programLinkedList.getSize()));

            if (positionToUpdate != -1) { // proceed only if user didn't enter -1
                Programme currentProgramme = programLinkedList.getEntry(positionToUpdate - 1);
                ArraySortedSetList<Tutorial> currentProgrammeList = currentProgramme.getProgrammeList();

                // Prompt user for updated information
                System.out.println("Enter Programme Code: (or -1 to exit)");
                String updatedCode = scanner.nextLine();
                if (updatedCode.equals("-1")) {
                    return; // exit case statement
                }


              
                    System.out.println("Enter Programme Name: (or -1 to exit)");
                    String updatedName = scanner.nextLine();
                if (updatedName.equals("-1")) {
                    return; // exit case statement
                }

                
              System.out.println("Enter Programme Leader: (or -1 to exit)");
                    String updatedLeader = scanner.nextLine();
                if (updatedLeader.equals("-1")) {
                    return; // exit case statement
                }
                
                
                Programme updatedProgramme = new Programme(updatedCode, updatedName, updatedLeader);
                updatedProgramme.setProgrammeList(currentProgrammeList);

                System.out.println("DO you want to update this Programme? (Y/N)");

                String confirmUpdate = promptForValidInput("");

                if (confirmUpdate.equalsIgnoreCase("Y")) {
                    programLinkedList.replace(positionToUpdate - 1, updatedProgramme);
                    System.out.println("Programme successfully updated  !\n");
                } else if (confirmUpdate.equalsIgnoreCase("N")) {
                    System.out.println("Programme not updated.\n");
                    return;
                }
            }
        }
    }
    
    public static void displayAllTutorialForProgramme() {
        if (programLinkedList.isEmpty()) {
            System.out.println("\nThe current list is empty, Please add new Programme first. (Y)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("y")) {
                return;
            } else {
                System.out.println("Exiting...\n");
            }
        } else {
            System.out.println("\nCurrent Programme List:\n");
            ProgramManagement.showProgrammeList();

          

            System.out.println("Press Y to go back:");
            String backToProgramMenu;

            // Validate backToProgramMenu input
            do {
                backToProgramMenu = scanner.nextLine();
                if (!backToProgramMenu.equalsIgnoreCase("Y")) {
                    System.out.println("Invalid input. Please enter Y only");
                }
            } while (!backToProgramMenu.equalsIgnoreCase("Y"));
        }
    }
   



    public static void showProgrammeList() {
        for (int i = 0; i < programLinkedList.getSize(); i++) {
            System.out.println((i + 1) + "." + programLinkedList.getEntry(i).toString());
            System.out.println("Tutorial Group:");
            ArraySortedSetList<Tutorial> programmeList = programLinkedList.getEntry(i).getProgrammeList();
            showProgrammeList(programmeList);
        }
    }

    private static void showProgrammeList(ArraySortedSetList<Tutorial> programmeList) {
        if (programmeList.isEmpty()) {
            System.out.println("No Tutorial Group found for this Programme.\n");
        } else {
            for (int j = 0; j < programmeList.getSize(); j++) {
                Tutorial group = programmeList.getEntry(j);
                if (group != null) {
                    System.out.println((j + 1) + ". " + group.getCode());
                }
            }
            System.out.println("\n");
        }
    }
    
        public static void displayProgrammeList() {
        if (programLinkedList.isEmpty()) {
            System.out.println("\nThe current list is empty, Please add new Programme first. (Y)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("y")) {
                return;
            } else {
                System.out.println("Exiting...\n");
            }
        } else {
            System.out.println("\nCurrent Programme List:\n");
            viewProgrammeList();

            // Show past Programme if any
        

            System.out.println("Press Y to go back:");
            String backToProgramMenu;

            // Validate backToProgramMenu input
            do {
                backToProgramMenu = scanner.nextLine();
                if (!backToProgramMenu.equalsIgnoreCase("Y")) {
                    System.out.println("Invalid input. Please enter Y only");
                }
            } while (!backToProgramMenu.equalsIgnoreCase("Y"));
        }
    }

        
            public static void viewProgrammeList() {
        for (int i = 0; i < programLinkedList.getSize(); i++) {
            System.out.println((i + 1) + ". " + programLinkedList.getEntry(i).toString());
       
              }
    }
     


    
    
      private static void generateReport() {
          
             if (programLinkedList.isEmpty()) {
            System.out.println("\nThe current list is empty, Please add new Programme first. (Y)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("y")) {
                return;
            } else {
                System.out.println("Exiting...\n");
            }
        } else {
            System.out.println("\nCurrent Programme List:\n");
            viewProgrammeList();

            // Show past Programme if any
           int count = programLinkedList.getSize();
        
        
        System.out.println("");
        System.out.println("Total count of entries in the list: " + count);
         System.out.println("\n");
         
         
         

            System.out.println("Press Y to go back:");
            String backToProgramMenu;

            // Validate backToProgramMenu input
            do {
                backToProgramMenu = scanner.nextLine();
                if (!backToProgramMenu.equalsIgnoreCase("Y")) {
                    System.out.println("Invalid input. Please enter Y only");
                }
            } while (!backToProgramMenu.equalsIgnoreCase("Y"));
        }
                

        
    }


}
