package Entities;

import ADT.ArraySortedSetList;
import Client.TutorialManagement;
import java.util.List;

import java.util.Objects;

public class Programme implements Comparable<Programme> {
    private int programmeNo;
    private String code;
    private String name;
    private String leader;
    private ArraySortedSetList<Tutorial> programmeList = new ArraySortedSetList<>();



    public Programme(int programmeNo, String code, String name, String leader) {
        this.programmeNo = programmeNo;
        this.code = code;
        this.name = name;
        this.leader = leader;
    }

    public Programme(String code, String name, String leader) {
        this.code = code;
        this.name = name;
        this.leader = leader;
    }

    public Programme(String code) {
        this.code = code;
    }

    public int getProgrammeNo() {
        return programmeNo;
    }

    public void setProgrammeNo(int programmeNo) {
        this.programmeNo = programmeNo;
    }

    public ArraySortedSetList<Tutorial> getProgrammeList() {
        return programmeList;
    }

    public void setProgrammeList(ArraySortedSetList<Tutorial> programmeList) {
        this.programmeList = programmeList;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public void addTutorial(Tutorial n) {
        programmeList.add(n);
    }

    public Tutorial removeTutorial(Tutorial n) {
        return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Programme subject = (Programme) o;
        return Objects.equals(code, subject.code);
    }

    @Override
    public int compareTo(Programme o) {
        return this.code.compareTo(o.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name, leader);
    }

    @Override
    public String toString() {
        return "Programme Code  : " + code + "\n   Programme Name  : " + name + " \n   Programme Leader: " + leader + "\n";
    }

    public List<TutorialManagement> displayAllTutorialForProgramme() {
       return (List<TutorialManagement>) programmeList;
    }

}