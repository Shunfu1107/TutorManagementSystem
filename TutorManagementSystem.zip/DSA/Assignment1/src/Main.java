import Client.*;

import Entities.Programme;
import Entities.Tutorial;

import java.io.Console;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    private static Scanner scan = new Scanner(System.in);

    public static void clearConsole() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception E) {
            System.out.println(E);
        }
    }

    public static void generateDefaultData(){
        TutorialManagement.TutorialTable.put("G1",new Tutorial("G1", 18, "RIS"));
        TutorialManagement.TutorialTable.put("G2",new Tutorial("G2", 30, "RIT"));
        TutorialManagement.TutorialTable.put("G3",new Tutorial("G3", 21, "RIS"));
        TutorialManagement.TutorialTable.put("G4",new Tutorial("G4", 25, "RIS"));
        
        TutorialManagement.TutorialTable.put("G5",new Tutorial("G5", 18, "RIS"));
        TutorialManagement.TutorialTable.put("G6",new Tutorial("G6", 30, "RIS"));
        TutorialManagement.TutorialTable.put("G7",new Tutorial("G7", 21, "RIS"));
        TutorialManagement.TutorialTable.put("G8",new Tutorial("G8", 25, "RIS"));
        
        TutorialManagement.TutorialTable.put("G9",new Tutorial("G9", 18, "RIS"));
        TutorialManagement.TutorialTable.put("G10",new Tutorial("G10", 30, "RIS"));
        TutorialManagement.TutorialTable.put("G11",new Tutorial("G11", 21, "RIS"));
        TutorialManagement.TutorialTable.put("G12",new Tutorial("G12", 25, "RIS"));
            
        ProgramManagement.programLinkedList.add(new Programme(1,"BACS2000", "Data Structure", "ALI"));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(1));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(2));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(3));
        ProgramManagement.programLinkedList.getEntry(0).addTutorial(TutorialManagement.getTutorial(4));

        ProgramManagement.programLinkedList.add(new Programme(2, "BACS2001","HCI", "ABU"));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(5));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(6));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(7));
        ProgramManagement.programLinkedList.getEntry(1).addTutorial(TutorialManagement.getTutorial(8));

        ProgramManagement.programLinkedList.add(new Programme( 3,"BACS2002", "OOAD", "John"));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(9));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(10));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(11));
        ProgramManagement.programLinkedList.getEntry(2).addTutorial(TutorialManagement.getTutorial(12));
    }
    
    public static void main(String[] args) {
       generateDefaultData();
        int choice = 0;
        do {
            //clearConsole();
            System.out.println("Welcome to the Programme and Tutorial Management Subsystem");
            System.out.println("1. Programme");
            System.out.println("2. Tutorial");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            try {
                choice = scan.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, please try again.");
            }
            scan.nextLine();
            switch (choice) {
                case 1:
                    ProgramManagement.programmeMenu();
                    break;
                case 2:
                    TutorialManagement.showTutorialMenu();
                    break;
                
                default:
                    break;
            }
        } while (choice != 3);
    }
}