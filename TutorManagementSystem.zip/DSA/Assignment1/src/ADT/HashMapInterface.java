package ADT;

import java.util.Iterator;

public interface HashMapInterface<K, V> {
    public void put(K key, V value);
    public V remove(K key);
    public V retrieve(K key);
    public int getNumberOfEntries();
    public void clear();
    public Iterator<V> getIterator();
}
