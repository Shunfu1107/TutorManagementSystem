package ADT;

public interface SortedListInterface <T>{

    public void add (T newEntry);
    public boolean add(int position, T newEntry);
    public T remove(int position);
    public void clear();
    public T getEntry(int position);
    public boolean replace(int position, T newEntry);
    public boolean contains(T entry);
    public int getNumberOfEntries();
    public boolean isEmpty();
    public int getPosition(T entry);




}
