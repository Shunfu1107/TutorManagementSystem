package ADT;


import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArraySortedSetList<T> implements SortedListInterface<T>{
    private Programme head;
    private Programme tail;
    private int size; // list allocated size



  
    private class Programme{

        private T data;
        private Programme next;

        Programme(){
            this.data = null;
            this.next = null;
        }

        Programme(T data){
            this.data = data;
            this.next = null;
        }

        Programme(T data, Programme n){
            this.data = data;
            this.next = n;
        }
    }

    public int getSize(){
        return size;
    }

    public void setSize(int s){
        size = s;
    }

    public ArraySortedSetList() {
        head = null;
        tail = null;
        size = 0;
    }

    ArraySortedSetList(T data){
        head = new Programme(data);
        size = 1;
    }

    public void add(T newEntry){
        Programme newNode = new Programme(newEntry);

        if(isEmpty()){
            head = newNode;
        } else {
            Programme currentNode = head;
            while(currentNode.next != null){
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            tail = newNode;
        }
        size++;
    }

    public boolean add(int position, T newEntry) {
        if (newEntry == null || position < 0 || position > size) {
            return false;
        }
        Programme newProgram = new Programme(newEntry);
        if (position == 0) {
            newProgram.next = head;
            head = newProgram;
        } else {
            Programme currentProgram = getProgramAt(position - 1);
            newProgram.next = currentProgram.next;
            currentProgram.next = newProgram;
        }
        size++;
        return true;
    }

    private Programme getProgramAt(int position) {
        if (position >= 0 && position < size) {
            Programme currentProgram = head;
            for (int i = 0; i < position; i++) {
                currentProgram = currentProgram.next;
            }
            return currentProgram;
        }
        return null;
    }

    public T remove(int position){
        if(position >= 0 && position < size){
            Programme currentProgram = head;
            Programme previousProgram = null;
            if(position == 0){ // case when removing first element
                head = currentProgram.next;
            }else{
                for(int i = 0; i < position; i++){
                    previousProgram = currentProgram;
                    currentProgram = currentProgram.next;
                }
                previousProgram.next = currentProgram.next;
            }
            size--;
            return (T) currentProgram.data;
        }
        return null;
    }


    public void clear(){
        head = tail = null;
        size = 0;
    }

    public boolean replace(int position, T newEntry){
        if(position >= 0 && position < this.size){
            Programme currentProgram = head;
            for(int i = 0; i < position; i++){
                currentProgram = currentProgram.next;
            }
            currentProgram.data = newEntry;
            return true;
        }
        return false;
    }

    public T getEntry(int position){
        if(position >= 0 && position < this.size){
            Programme currentProgram = head;
            for(int i = 0; i < position; i++){
                currentProgram = currentProgram.next;
            }
            return (T) currentProgram.data;
        }
        return null;
    }

    public int getPosition(T entry) {
        Programme currentProgram = head;
        int position = -1;
        for (int i = 0; i < size; i++) {
            if (currentProgram.data.equals(entry)) {
                position = i;
                break;
            }
            currentProgram = currentProgram.next;
        }
        return position;
    }


    public boolean contains(T entry){
        Programme currentProgram = head;
        for(int i = 0; i < size; i++){
            if(currentProgram.data.equals(entry)){
                return true;
            }
            currentProgram = currentProgram.next; // move to the next node
        }
        return false;
    }


    public Iterator<T> iterator() {
        return new LinkedListIterator();
    }

    public class LinkedListIterator implements Iterator<T> {
        private Programme nextProgram;

        public LinkedListIterator() {
            nextProgram = head;
        }

        public boolean hasNext() {
            return nextProgram != null;
        }

        public T next() {
            T result;
            if (hasNext()) {
                result = nextProgram.data;
                nextProgram = nextProgram.next;
            } else {
                throw new NoSuchElementException();
            }
            return result;
        }
    }


    @Override
    public int getNumberOfEntries() {
        return size;
    }

    public boolean isEmpty(){
        return size == 0;
    }


}