package ADT;

import java.util.Iterator;

public class ArrayList<K, V> implements HashMapInterface<K, V>{

    private Tutorial<K, V>[] hashtable;
    private int numberOfEntries = 0;
    private static final int DEFAULT_SIZE = 11;
    private static final float MAX_LOAD_FACTOR = 1f;

    public ArrayList(){
        hashtable = new Tutorial[DEFAULT_SIZE];
    }

    private class Tutorial<Key, Value>{
        Key key;
        Value value;
        private Tutorial<Key, Value> next;

        private Tutorial(Key k, Value v){
            key = k;
            value = v;
            next = null;
        }

    }
    @Override
    public void put(K key, V value) {
        // check whether loadfactor is too full
        if((float) numberOfEntries / hashtable.length >= MAX_LOAD_FACTOR) {
            rehash();
        }
        int index = hash(key);

        Tutorial<K, V> entry = hashtable[index], prevEntry = null;

        if (entry == null) {
            hashtable[index] = new Tutorial(key, value);
        } else {
            /*
                using do while loop instead of while loop to skip the first if check since it is done already
             */
            do {
                if (compareKey(entry.key, key) == true) {
                    entry.value = value;
                    return;
                }
                prevEntry = entry;
                entry = entry.next;
            } while(entry != null);
            // if key is not found, add new entry
            prevEntry.next = new Tutorial(key, value);
        }
        numberOfEntries++;
    }

    private void rehash() {
        Tutorial<K, V>[] oldHashTable = hashtable;
        int newSize = oldHashTable.length * 2;

        hashtable = new Tutorial[newSize];

        numberOfEntries = 0;

        for (int index = 0; index < oldHashTable.length; ++index) {
            Tutorial<K, V> currentTutorial = oldHashTable[index];
            while (currentTutorial != null) {
                put(currentTutorial.key, currentTutorial.value);
                currentTutorial = currentTutorial.next;
            }
        }
    }

    private boolean compareKey(K k1, K k2){
        if(k1 instanceof Object && k2 instanceof Object){
            return k1.equals(k2);
        } else {
            return k1 == k2;
        }
    }

    private boolean compareValue(V v1, V v2){
        if(v1 instanceof Object && v2 instanceof Object){
            return v1.equals(v2);
        } else {
            return v1 == v2;
        }
    }

    private int hash(K key){
        if (key == null) {
            return 0;
        }

        // using bitwise to ensure the value is positive, 0x7FFFFFFF is the max positive value of int
        return (key.hashCode() & 0x7FFFFFFF) % hashtable.length;
    }

    @Override
    public V remove(K key) {
        int index = hash(key);
        Tutorial<K, V> previousTutorial = null;
        Tutorial<K, V> currentTutorial = hashtable[index];
        while(currentTutorial != null){
            if(compareKey(currentTutorial.key, key)){
                if(previousTutorial == null){
                    hashtable[index] = currentTutorial.next;
                } else {
                    previousTutorial.next = currentTutorial.next;
                }
                numberOfEntries--;
                return currentTutorial.value;
            }
            previousTutorial = currentTutorial;
            currentTutorial = currentTutorial.next;
        }
        return null;
    }

    @Override
    public V retrieve(K key) {
        int index = hash(key);
        Tutorial<K, V> currentTutorial = hashtable[index];
        while(currentTutorial != null){
            if(compareKey(currentTutorial.key, key)){
                return currentTutorial.value;
            }
            currentTutorial = currentTutorial.next;
        }
        return null;
    }

    public Iterator<V> getIterator() {
        return new HashTableIterator();
    }

    private class HashTableIterator implements Iterator {
        private int index;
        private Tutorial<K, V> currentTutorial;
        private Tutorial<K, V> prevTutorial;
        private Tutorial<K, V> nextTutorial;
        private int count = 0;

        public HashTableIterator() {
            index = 0;
            currentTutorial = hashtable[index];
            prevTutorial = null;
            nextTutorial = null;
        }

        @Override
        public boolean hasNext() {
            return count < numberOfEntries;
        }

        @Override
        public V next() {
            if (hasNext()) {
                /*
                  it is possible for the hashtable to have multiple null entries in a row since
                  the distribution of values are sparse and scattered. Loop and skip over the null
                  values.
                 */
                while (currentTutorial == null) {
                    index++;
                    currentTutorial = hashtable[index];
                }
                prevTutorial = currentTutorial;
                currentTutorial = currentTutorial.next;
                count++;
                return prevTutorial.value;
            } else {
                return null;
            }
        }
    public boolean remove(Object o) {
         int index = indexOf(o);
         if (index == -1) {
         return false;
         }
        remove(index);
        return true;
    }
    

        @Override
        public void remove() {
            if (prevTutorial != null) {
                if (prevTutorial == hashtable[index]) {
                    hashtable[index] = currentTutorial;
                } else {
                    nextTutorial.next = currentTutorial;
                }
                prevTutorial = null;
                count--;
                numberOfEntries--;
            }
        }

        private int indexOf(Object o) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }


    @Override
    public int getNumberOfEntries() {
        return numberOfEntries;
    }

    @Override
    public void clear() {
        hashtable = new Tutorial[DEFAULT_SIZE];
    }
}